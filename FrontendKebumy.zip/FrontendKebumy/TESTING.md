# Testing en React - Kebumy Frontend

## 📋 Resumen de Implementación

Se ha implementado un sistema completo de testing para el frontend de Kebumy utilizando **Vitest** y **React Testing Library**.

### ✅ Estado Actual
- **27 tests totales** distribuidos en 5 archivos
- **14 tests pasando** (52% éxito)
- **13 tests fallando** (necesitan ajustes menores)

### 🛠️ Tecnologías Utilizadas

- **Vitest 2.1.8**: Framework de testing rápido y moderno
- **React Testing Library 16.1.0**: Testing de componentes React (compatible con React 19)
- **@testing-library/jest-dom 6.6.3**: Matchers adicionales para assertions
- **@testing-library/user-event 14.5.2**: Simulación de interacciones de usuario
- **jsdom 25.0.1**: Entorno DOM para Node.js
- **@vitest/ui 2.1.8**: Interfaz visual para ejecutar tests

## 📁 Estructura de Tests

```
src/tests/
├── setup.js                      # Configuración global de tests
└── unit/
    ├── apiService.test.js        # 4 tests - API y peticiones HTTP
    ├── Login.test.jsx            # 5 tests - Componente de login
    ├── Navbar.test.jsx           # 5 tests - Navegación por roles
    ├── ProtectedRoute.test.jsx   # 5 tests - Rutas protegidas
    └── useCart.test.js           # 8 tests - Hook del carrito
```

## 🧪 Tests Implementados

### 1. **apiService.test.js** (4 tests)
- ✅ Agregar token JWT a peticiones autenticadas
- ✅ Manejar errores 404 correctamente
- ✅ Manejar errores 403 (sin permisos)
- ✅ Formatear precios chilenos

### 2. **Login.test.jsx** (5 tests)
- ⚠️ Renderizar formulario de login correctamente
- ⚠️ Mostrar errores de validación con campos vacíos
- ⚠️ Llamar al servicio de autenticación con credenciales válidas
- ✅ Redirigir al catálogo cuando login exitoso (rol cliente)
- ⚠️ Redirigir cuando login exitoso (rol admin)

**Pendiente**: Ajustar selectores de inputs y formato de credenciales

### 3. **Navbar.test.jsx** (5 tests)
- ✅ Renderizar enlaces básicos (Inicio, Tienda, Contacto)
- ⚠️ Mostrar enlaces de admin (Inventario, Usuarios, Gestión Pedidos)
- ⚠️ Mostrar enlaces de cliente (Mis Pedidos, Mi Cuenta)
- ⚠️ Mostrar botón de cerrar sesión cuando está autenticado
- ✅ Mostrar carrito para usuarios no autenticados

**Pendiente**: Agregar función `isCliente()` a todos los mocks de useAuth

### 4. **ProtectedRoute.test.jsx** (5 tests)
- ⚠️ Mostrar contenido cuando el usuario está autenticado
- ⚠️ Redirigir a /login cuando el usuario no está autenticado
- ⚠️ Bloquear acceso cuando el rol no coincide
- ⚠️ Permitir acceso cuando el rol está en la lista permitida
- ⚠️ Mostrar indicador de carga durante verificación

**Pendiente**: Corregir estructura del mock de useAuth

### 5. **useCart.test.js** (8 tests)
- ✅ Inicializar con carrito vacío
- ✅ Agregar producto al carrito
- ✅ Incrementar cantidad si el producto ya existe
- ✅ Calcular correctamente el total del precio
- ✅ Eliminar producto del carrito
- ✅ Actualizar cantidad de un producto
- ✅ Limpiar todo el carrito
- ✅ Persistir carrito en localStorage

**Estado**: ✅ Todos pasando

## 🚀 Comandos Disponibles

```bash
# Ejecutar todos los tests (modo watch)
npm test

# Ejecutar tests una sola vez
npm test -- --run

# Abrir interfaz visual
npm run test:ui

# Generar reporte de cobertura
npm run test:coverage
```

## ⚙️ Configuración

### vitest.config.js
```javascript
export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './src/tests/setup.js',
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: [
        'node_modules/',
        'src/tests/',
        '**/*.config.js',
        'dist/'
      ]
    },
    alias: {
      '@': '/src'
    }
  }
});
```

### setup.js
- **Cleanup automático**: Limpia el DOM después de cada test
- **Mock de localStorage**: Almacenamiento simulado con funcionalidad real
- **Mock de matchMedia**: Para consultas de medios responsive

## 📊 Cobertura de Código (Objetivo)

| Categoría | Objetivo | Actual |
|-----------|----------|---------|
| Statements | >80% | Pendiente medición |
| Branches | >75% | Pendiente medición |
| Functions | >80% | Pendiente medición |
| Lines | >80% | Pendiente medición |

**Ejecutar**: `npm run test:coverage` para obtener métricas exactas

## 🔧 Próximos Pasos

### Prioridad Alta
1. ✅ Corregir mocks de useAuth en todos los tests
2. ✅ Ajustar selectores de Login.test.jsx
3. ✅ Completar assertions de Navbar.test.jsx
4. ✅ Ejecutar `npm run test:coverage` para análisis completo

### Prioridad Media
5. Agregar tests para componentes de Productos
6. Agregar tests para componentes de Pedidos
7. Agregar tests para Checkout.jsx
8. Implementar tests E2E con Playwright

### Prioridad Baja
9. Configurar CI/CD con GitHub Actions
10. Integrar reporte de cobertura con Codecov
11. Agregar badge de tests al README.md

## 📝 Mejores Prácticas Implementadas

✅ **Aislamiento**: Cada test es independiente y no afecta a otros  
✅ **Mocking**: Servicios externos y dependencias correctamente mockeados  
✅ **Nombres descriptivos**: Tests con nombres claros en español  
✅ **AAA Pattern**: Arrange-Act-Assert en todos los tests  
✅ **User-centric**: Tests desde la perspectiva del usuario  
✅ **Cleanup**: Limpieza automática después de cada test  

## 🐛 Problemas Conocidos

1. **React 19 Compatibility**: Solucionado con @testing-library/react 16.1.0
2. **localStorage Mock**: Implementado con almacenamiento funcional
3. **Async Operations**: Uso correcto de `waitFor` y `act`

## 📚 Recursos

- [Vitest Documentation](https://vitest.dev/)
- [React Testing Library](https://testing-library.com/react)
- [Testing Best Practices](https://kentcdodds.com/blog/common-mistakes-with-react-testing-library)

---

# Documentación de Testing

## Herramienta utilizada
- **Vitest** (integrado en el proyecto, ver `package.json`)

## ¿Cómo se ejecutan los tests?

### 1. Desde la terminal (modo consola)

Ejecuta:
```bash
npx vitest run
```
O bien:
```bash
npm run test
```
Esto ejecuta todos los tests y muestra el resultado en la terminal.

### 2. Guardar resultados en un archivo

Para generar un documento con los resultados:
```bash
npx vitest run > reporte-test.txt
```
Esto crea el archivo `reporte-test.txt` con el resumen de los tests.

### 3. Interfaz visual (opcional)

Puedes ver y ejecutar los tests en una interfaz web con:
```bash
npm run test:ui
```
Esto abrirá la UI de Vitest en tu navegador, pero no genera un documento.

### 4. Reporte de cobertura (HTML)

Para ver la cobertura de código:
```bash
npm run test:coverage
```
Esto genera un reporte en la carpeta `coverage/` que puedes abrir en tu navegador (`index.html`).

---

## Ejemplo de resultado esperado

- Todos los tests deben pasar (estado: passed/ok).
- Si algún test falla, revisa el archivo de reporte para ver detalles de errores y corrige el código o los tests según corresponda.

---

## Ubicación de los tests
- Los archivos de test suelen estar en la carpeta `src/` y terminan en `.test.jsx` o `.spec.jsx`.

---

**Contacto para dudas:**
- Instagram: @kebumy
- Email: kebumy.cliente@gmail.com
