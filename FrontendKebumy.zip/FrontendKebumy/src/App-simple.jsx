import React from 'react';

function App() {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>🚀 Kebumy - Test Simple</h1>
      <p>Si ves este mensaje, React está funcionando correctamente.</p>
      <div style={{ marginTop: '20px' }}>
        <a href="/catalogo" style={{ margin: '0 10px', color: '#007bff' }}>Catálogo</a>
        <a href="/carrito" style={{ margin: '0 10px', color: '#007bff' }}>Carrito</a>
        <a href="/mi-cuenta" style={{ margin: '0 10px', color: '#007bff' }}>Mi Cuenta</a>
        <a href="/pedidos" style={{ margin: '0 10px', color: '#007bff' }}>Pedidos</a>
      </div>
    </div>
  );
}

export default App;