import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/Home/Home'; 
import Contacto from './pages/Contacto/Contacto'; 
import Inventario from './pages/Inventario/Inventario'; 
import CrearProducto from './components/CrearProd/CrearProducto'; 
import Login from './pages/Login/Login'; 
import Register from './pages/Register/Register';
import AdminUsuarios from './pages/Usuarios/Adminusuarios';
import CrearUsuario from './components/Usuarios/CrearUsuario';
import ProtectedRoute from './components/ProtectedRoute';
import BackendToggle from './components/BackendToggle/BackendToggle';
import GestionPedidos from './pages/Admin/GestionPedidos/GestionPedidos';

// Componentes Cliente
import Catalogo from './pages/Cliente/Catalogo/Catalogo';
import Carrito from './pages/Cliente/Carrito/Carrito';
import MiCuenta from './pages/Cliente/MiCuenta/MiCuenta';
import Pedidos from './pages/Cliente/Pedidos/Pedidos';
import PagoExitoso from './pages/Cliente/PagoExitoso/PagoExitoso';
import Checkout from './pages/Cliente/Checkout/Checkout';
import PedidoExitoso from './pages/Cliente/PedidoExitoso/PedidoExitoso';

import './App.css'; 
import './styles/GlobalStyles.css';

function App() {
  console.log('🚀 App component is rendering...');
  
  return (
    <Router>
      {/* Componente para alternar entre backend real y mock (solo en desarrollo) */}
      {import.meta.env.DEV && <BackendToggle />}
      
      <Routes>
        {/* Rutas Públicas */}
        <Route path="/" element={<Home />} /> 
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/login" element={<Login />} /> 
        <Route path="/registro" element={<Register />} /> 
        
        {/* Rutas Protegidas - Solo para administradores */}
        <Route 
          path="/inventario" 
          element={
            <ProtectedRoute requiredRole={['admin', 'super-admin']}>
              <Inventario />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/crear-producto" 
          element={
            <ProtectedRoute requiredRole={['admin', 'super-admin']}>
              <CrearProducto />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin-usuarios" 
          element={
            <ProtectedRoute requiredRole={['admin', 'super-admin']}>
              <AdminUsuarios />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/crear-usuario" 
          element={
            <ProtectedRoute requiredRole={['admin', 'super-admin']}>
              <CrearUsuario />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/gestion-pedidos" 
          element={
            <ProtectedRoute requiredRole={['admin', 'super-admin']}>
              <GestionPedidos />
            </ProtectedRoute>
          } 
        />
        
        {/* Rutas Cliente - Accesibles para todos los usuarios */}
        <Route path="/catalogo" element={<Catalogo />} />
        <Route path="/carrito" element={<Carrito />} />
        <Route path="/pago-exitoso" element={<PagoExitoso />} />
        <Route path="/checkout/:pedidoId" element={<Checkout />} />
        <Route path="/pedido-exitoso/:pedidoId" element={<PedidoExitoso />} />
        
        {/* Rutas Cliente - Solo para clientes autenticados */}
        <Route 
          path="/mi-cuenta" 
          element={
            <ProtectedRoute>
              <MiCuenta />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/pedidos" 
          element={
            <ProtectedRoute>
              <Pedidos />
            </ProtectedRoute>
          } 
        />
        
        {/* Ruta por defecto - redirige a Home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;