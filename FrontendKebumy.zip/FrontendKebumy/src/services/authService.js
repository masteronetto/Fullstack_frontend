// src/services/authService.js
// Servicio de autenticación con manejo JWT

import httpClient, { post } from './httpClient';

/**
 * Servicio de autenticación
 * Maneja login, logout, validación de tokens, etc.
 */
class AuthService {
  /**
   * Login de usuario
   * @param {Object} credentials - { email, password }
   * @returns {Promise<Object>} - Respuesta del backend con token y usuario
   */
  async login(credentials) {
    console.log('🔐 AuthService - Intentando login para:', credentials.email);
    
    try {
      // Hacer petición de login (sin token, endpoint público)
      const response = await httpClient.post('/usuarios/login', credentials, {
        // No enviar token en el login
        transformRequest: [(data, headers) => {
          delete headers.Authorization;
          return JSON.stringify(data);
        }],
      });
      
      console.log('✅ AuthService - Login exitoso');
      console.log('👤 AuthService - Usuario:', response.data.usuario);
      console.log('🎭 AuthService - Rol:', response.data.usuario?.rol);
      
      // Guardar token en localStorage (lo hará el hook useAuth también)
      if (response.data.token) {
        localStorage.setItem('kebumy_token', response.data.token);
        console.log('💾 AuthService - Token guardado en localStorage');
      }
      
      return response.data;
    } catch (error) {
      console.error('❌ AuthService - Error en login:', error);
      
      if (error.response) {
        // Error del backend
        const message = error.response.data?.message || 'Credenciales incorrectas';
        throw new Error(message);
      } else if (error.request) {
        // Error de red
        throw new Error('No se pudo conectar al servidor. Verifica tu conexión.');
      } else {
        // Otro error
        throw new Error(error.message || 'Error desconocido');
      }
    }
  }

  /**
   * Logout de usuario
   */
  async logout() {
    console.log('🚪 AuthService - Cerrando sesión...');
    
    try {
      // Opcional: Llamar al backend para invalidar el token
      // await httpClient.post('/usuarios/logout');
      
      // Limpiar localStorage
      localStorage.removeItem('kebumy_token');
      localStorage.removeItem('kebumy_user');
      
      console.log('✅ AuthService - Sesión cerrada exitosamente');
    } catch (error) {
      console.error('❌ AuthService - Error al cerrar sesión:', error);
      // Limpiar localStorage de todas formas
      localStorage.removeItem('kebumy_token');
      localStorage.removeItem('kebumy_user');
    }
  }

  /**
   * Registro de nuevo usuario
   * @param {Object} userData - { nombre, email, password, telefono?, direccion? }
   * @returns {Promise<Object>} - Respuesta del backend con token y usuario
   */
  async register(userData) {
    console.log('📝 AuthService - Registrando nuevo usuario:', userData.email);
    
    try {
      // Hacer petición de registro (sin token, endpoint público)
      const response = await httpClient.post('/usuarios/registro', userData, {
        // No enviar token en el registro
        transformRequest: [(data, headers) => {
          delete headers.Authorization;
          return JSON.stringify(data);
        }],
      });
      
      console.log('✅ AuthService - Registro exitoso');
      console.log('👤 AuthService - Usuario creado:', response.data.usuario);
      console.log('🎭 AuthService - Rol asignado:', response.data.usuario?.rol);
      
      // Guardar token en localStorage (login automático después del registro)
      if (response.data.token) {
        localStorage.setItem('kebumy_token', response.data.token);
        console.log('💾 AuthService - Token guardado en localStorage');
      }
      
      return response.data;
    } catch (error) {
      console.error('❌ AuthService - Error en registro:', error);
      
      if (error.response) {
        // Error del backend
        const message = error.response.data?.message || 'Error al registrar usuario';
        const errors = error.response.data?.errors;
        
        if (errors) {
          // Si hay errores de validación, formatearlos
          const errorMessages = Object.values(errors).flat().join(', ');
          throw new Error(errorMessages);
        }
        
        throw new Error(message);
      } else if (error.request) {
        // Error de red
        throw new Error('No se pudo conectar al servidor. Verifica tu conexión.');
      } else {
        // Otro error
        throw new Error(error.message || 'Error desconocido');
      }
    }
  }

  /**
   * Verificar si el token es válido
   * @returns {boolean}
   */
  isTokenValid() {
    const token = localStorage.getItem('kebumy_token');
    
    if (!token) {
      console.log('⚠️ AuthService - No hay token');
      return false;
    }
    
    try {
      // Decodificar el payload del JWT (segunda parte del token)
      const payload = JSON.parse(atob(token.split('.')[1]));
      const currentTime = Math.floor(Date.now() / 1000);
      
      // Verificar expiración
      if (payload.exp && payload.exp < currentTime) {
        console.warn('⏰ AuthService - Token expirado');
        this.logout(); // Limpiar sesión expirada
        return false;
      }
      
      console.log('✅ AuthService - Token válido');
      return true;
    } catch (error) {
      console.error('❌ AuthService - Error al validar token:', error);
      return false;
    }
  }

  /**
   * Obtener el usuario actual del token
   * @returns {Object|null}
   */
  getCurrentUser() {
    const userStr = localStorage.getItem('kebumy_user');
    
    if (!userStr) {
      return null;
    }
    
    try {
      return JSON.parse(userStr);
    } catch (error) {
      console.error('❌ AuthService - Error al parsear usuario:', error);
      return null;
    }
  }

  /**
   * Verificar si el usuario actual tiene un rol específico
   * @param {string|string[]} roles - Rol o array de roles
   * @returns {boolean}
   */
  hasRole(roles) {
    const user = this.getCurrentUser();
    
    if (!user || !user.rol) {
      return false;
    }
    
    if (Array.isArray(roles)) {
      return roles.includes(user.rol);
    }
    
    return user.rol === roles;
  }

  /**
   * Verificar si el usuario es administrador
   * @returns {boolean}
   */
  isAdmin() {
    return this.hasRole(['admin', 'super-admin']);
  }

  /**
   * Verificar si el usuario es cliente
   * @returns {boolean}
   */
  isCliente() {
    return this.hasRole('cliente');
  }

  /**
   * Obtener el token actual
   * @returns {string|null}
   */
  getToken() {
    return localStorage.getItem('kebumy_token');
  }
}

// Exportar instancia única (Singleton)
const authService = new AuthService();
export default authService;
