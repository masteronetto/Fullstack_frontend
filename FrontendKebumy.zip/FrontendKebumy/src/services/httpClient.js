// src/services/httpClient.js
// Cliente HTTP con interceptores JWT automáticos

import axios from 'axios';
import { API_CONFIG } from '../config/api';

/**
 * Cliente HTTP configurado con interceptores para JWT
 * Maneja automáticamente:
 * - Agregar token JWT en headers de cada petición
 * - Refrescar token cuando expira
 * - Redirigir al login si el token es inválido
 * - Logging de peticiones y respuestas
 */

// Crear instancia de axios
const httpClient = axios.create({
  baseURL: API_CONFIG.BASE_URL,
  timeout: API_CONFIG.TIMEOUT,
  headers: API_CONFIG.DEFAULT_HEADERS,
});

/**
 * Interceptor de REQUEST
 * Se ejecuta antes de cada petición HTTP
 */
httpClient.interceptors.request.use(
  (config) => {
    // Obtener token del localStorage
    const token = localStorage.getItem('kebumy_token');
    
    if (token) {
      // Agregar token JWT al header Authorization
      config.headers.Authorization = `Bearer ${token}`;
      console.log('🔑 httpClient - Token JWT agregado a la petición');
    }
    
    console.log(`📤 httpClient - ${config.method?.toUpperCase()} ${config.url}`);
    console.log('📋 httpClient - Headers:', config.headers);
    
    return config;
  },
  (error) => {
    console.error('❌ httpClient - Error en request interceptor:', error);
    return Promise.reject(error);
  }
);

/**
 * Interceptor de RESPONSE
 * Se ejecuta después de cada respuesta HTTP
 */
httpClient.interceptors.response.use(
  (response) => {
    // Respuesta exitosa
    console.log(`✅ httpClient - Respuesta ${response.status} de ${response.config.url}`);
    
    return response;
  },
  async (error) => {
    const originalRequest = error.config;
    
    console.error(`❌ httpClient - Error en respuesta:`, error.response?.status);
    
    // Si el error es 401 (No autorizado)
    if (error.response?.status === 401) {
      console.warn('🚨 httpClient - Token inválido o expirado (401)');
      
      // Verificar si ya intentamos refrescar el token
      if (!originalRequest._retry) {
        originalRequest._retry = true;
        
        // Limpiar autenticación
        localStorage.removeItem('kebumy_token');
        localStorage.removeItem('kebumy_user');
        
        // Redirigir al login
        console.log('🚪 httpClient - Redirigiendo al login...');
        window.location.href = '/login';
        
        return Promise.reject(new Error('Sesión expirada. Por favor inicia sesión nuevamente.'));
      }
    }
    
    // Si el error es 403 (Forbidden)
    if (error.response?.status === 403) {
      console.error('🚫 httpClient - Acceso denegado (403)');
      return Promise.reject(new Error('No tienes permisos para realizar esta acción.'));
    }
    
    // Si el error es 404 (Not Found)
    if (error.response?.status === 404) {
      console.error('🔍 httpClient - Recurso no encontrado (404)');
      return Promise.reject(new Error('Recurso no encontrado.'));
    }
    
    // Si el error es 422 (Validation Error)
    if (error.response?.status === 422) {
      console.error('⚠️ httpClient - Error de validación (422)');
      const validationErrors = error.response?.data?.errors || {};
      return Promise.reject({
        message: 'Error de validación',
        errors: validationErrors
      });
    }
    
    // Si el error es 500 (Server Error)
    if (error.response?.status === 500) {
      console.error('💥 httpClient - Error del servidor (500)');
      return Promise.reject(new Error('Error interno del servidor. Intenta nuevamente más tarde.'));
    }
    
    // Otros errores
    return Promise.reject(error);
  }
);

/**
 * Método helper para hacer peticiones GET
 */
export const get = async (url, config = {}) => {
  try {
    const response = await httpClient.get(url, config);
    return response.data;
  } catch (error) {
    console.error(`❌ GET ${url} falló:`, error);
    throw error;
  }
};

/**
 * Método helper para hacer peticiones POST
 */
export const post = async (url, data = {}, config = {}) => {
  try {
    const response = await httpClient.post(url, data, config);
    return response.data;
  } catch (error) {
    console.error(`❌ POST ${url} falló:`, error);
    throw error;
  }
};

/**
 * Método helper para hacer peticiones PUT
 */
export const put = async (url, data = {}, config = {}) => {
  try {
    const response = await httpClient.put(url, data, config);
    return response.data;
  } catch (error) {
    console.error(`❌ PUT ${url} falló:`, error);
    throw error;
  }
};

/**
 * Método helper para hacer peticiones DELETE
 */
export const del = async (url, config = {}) => {
  try {
    const response = await httpClient.delete(url, config);
    return response.data;
  } catch (error) {
    console.error(`❌ DELETE ${url} falló:`, error);
    throw error;
  }
};

/**
 * Método helper para hacer peticiones PATCH
 */
export const patch = async (url, data = {}, config = {}) => {
  try {
    const response = await httpClient.patch(url, data, config);
    return response.data;
  } catch (error) {
    console.error(`❌ PATCH ${url} falló:`, error);
    throw error;
  }
};

export default httpClient;
