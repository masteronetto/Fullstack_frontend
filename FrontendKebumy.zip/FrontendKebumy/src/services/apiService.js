// src/services/apiService.js
// Servicio para manejar todas las llamadas a la API

import { API_CONFIG, MOCK_DATA, simulateNetworkDelay } from '../config/api.js';

class ApiService {
    constructor() {
        this.baseURL = API_CONFIG.BASE_URL;
        
        // Inicializar desde localStorage si existe
        const savedMode = localStorage.getItem('kebumy_backend_mode');
        if (savedMode !== null) {
            this.useRealBackend = JSON.parse(savedMode);
            API_CONFIG.USE_REAL_BACKEND = this.useRealBackend;
        } else {
            this.useRealBackend = API_CONFIG.USE_REAL_BACKEND;
        }
        
        console.log(`🔧 ApiService inicializado: ${this.useRealBackend ? 'Backend Real' : 'Modo Mock'}`);
        
        // Inicializar sistema robusto de imágenes
        ApiService.initializeImageCache();
        ApiService.cleanImageCache(); // Limpiar entradas viejas
    }

    // Método helper para hacer peticiones HTTP
    async makeRequest(url, options = {}) {
        const config = {
            mode: 'cors',
            credentials: 'omit',
            headers: {
                ...API_CONFIG.DEFAULT_HEADERS,
                ...options.headers,
            },
            ...options,
        };

        // Agregar token JWT de autenticación si existe y no se solicita omitirlo
        const skipAuth = options.skipAuth || false;
        const token = localStorage.getItem('kebumy_token');
        if (token && !skipAuth) {
            config.headers.Authorization = `Bearer ${token}`;
            console.log('🔑 Token JWT añadido a la petición');
        } else if (skipAuth) {
            console.log('🚫 Petición pública - Token JWT omitido');
        }

        console.log(`🌐 Haciendo petición a: ${this.baseURL}${url}`);
        console.log(`🔧 Configuración:`, { method: config.method || 'GET', headers: config.headers });

        try {
            const response = await fetch(`${this.baseURL}${url}`, config);
            
            console.log(`📥 Respuesta recibida:`, { status: response.status, statusText: response.statusText });
            
            // Manejar diferentes códigos de estado
            if (!response.ok) {
                await this.handleErrorResponse(response);
            }

            // Si la respuesta es exitosa, parsear JSON
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                try {
                    return await response.json();
                } catch (jsonError) {
                    console.error('❌ Error parseando JSON de respuesta:', jsonError);
                    // Intentar obtener el texto crudo para debug
                    const textResponse = await response.text();
                    console.error('📄 Respuesta cruda del servidor:', textResponse);
                    throw new Error(`Error parseando respuesta JSON: ${jsonError.message}`);
                }
            }
            
            return response;
        } catch (error) {
            console.error('❌ Error en la petición:', error);
            console.error('🔍 Detalles del error:', {
                name: error.name,
                message: error.message,
                url: `${this.baseURL}${url}`
            });
            
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                throw new Error(`Error de conexión: No se puede conectar al backend en ${this.baseURL}. Verifica que el backend esté corriendo.`);
            }
            
            throw error;
        }
    }

    // Manejar respuestas de error
    async handleErrorResponse(response) {
        const errorData = await response.json().catch(() => ({}));
        
        switch (response.status) {
            case 401:
                // Token inválido o expirado - limpiar autenticación
                localStorage.removeItem('kebumy_token');
                localStorage.removeItem('kebumy_user');
                throw new Error(errorData.message || API_CONFIG.ERROR_MESSAGES.UNAUTHORIZED);
            case 403:
                throw new Error(errorData.message || API_CONFIG.ERROR_MESSAGES.FORBIDDEN);
            case 404:
                throw new Error(errorData.message || API_CONFIG.ERROR_MESSAGES.NOT_FOUND);
            case 422:
                throw new Error(errorData.message || API_CONFIG.ERROR_MESSAGES.VALIDATION_ERROR);
            case 500:
                throw new Error(errorData.message || API_CONFIG.ERROR_MESSAGES.SERVER_ERROR);
            default:
                throw new Error(errorData.message || `Error ${response.status}: ${response.statusText}`);
        }
    }

    // === AUTENTICACIÓN ===
    
    async login(credentials) {
        console.log('🔐 Iniciando login con:', { email: credentials.email, useRealBackend: this.useRealBackend });
        
        if (!this.useRealBackend) {
            // Modo desarrollo con datos mock
            await simulateNetworkDelay();
            
            if (credentials.email === 'admin@kebumy.com' && credentials.password === 'admin123') {
                const mockResponse = {
                    success: true,
                    message: "Login exitoso",
                    token: "mock-jwt-token-12345",
                    usuario: {
                        id: 1,
                        id_usuario: 1,
                        nombre: "Admin Kebumy",
                        email: credentials.email,
                        rol: "admin",
                        tipo_usuario: "administrador"
                    }
                };
                
                // Guardar token en localStorage
                localStorage.setItem('kebumy_token', mockResponse.token);
                console.log('✅ Login mock exitoso:', mockResponse);
                return mockResponse;
            } else if (credentials.email === 'cliente@kebumy.com' && credentials.password === 'cliente123') {
                const mockResponse = {
                    success: true,
                    message: "Login exitoso",
                    token: "mock-jwt-token-67890",
                    usuario: {
                        id: 2,
                        id_usuario: 2,
                        nombre: "Cliente Demo",
                        email: credentials.email,
                        rol: "cliente",
                        tipo_usuario: "cliente"
                    }
                };
                
                localStorage.setItem('kebumy_token', mockResponse.token);
                console.log('✅ Login mock exitoso:', mockResponse);
                return mockResponse;
            } else {
                console.log('❌ Credenciales mock inválidas');
                throw new Error('Credenciales inválidas');
            }
        }

        // Modo producción con backend real
        console.log('🌐 Intentando login con backend real en:', `${this.baseURL}${API_CONFIG.ENDPOINTS.LOGIN}`);
        
        try {
            const loginData = {
                email: credentials.email,
                password: credentials.password
            };
            
            console.log('📤 Enviando datos de login:', { email: loginData.email });
            
            const response = await fetch(`${this.baseURL}${API_CONFIG.ENDPOINTS.LOGIN}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                mode: 'cors',
                body: JSON.stringify(loginData),
            });

            console.log('📥 Respuesta del login - Status:', response.status);

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: 'Error de conexión' }));
                console.error('❌ Error en login:', errorData);
                throw new Error(errorData.message || `Error ${response.status}`);
            }

            const data = await response.json();
            console.log('✅ Login response data:', data);

            // Validar la estructura de respuesta del backend
            if (data.success && data.token && data.usuario) {
                // Guardar token en localStorage
                localStorage.setItem('kebumy_token', data.token);
                console.log('🔑 Token JWT guardado en localStorage');
                console.log('👤 Usuario autenticado:', data.usuario);
                console.log('🎭 Rol:', data.usuario.rol);
                
                return data;
            } else {
                console.error('❌ Estructura de respuesta incorrecta:', data);
                throw new Error(data.message || 'Error en la autenticación');
            }
        } catch (error) {
            console.error('💥 Error completo en login:', error);
            
            // Diagnosticar el tipo de error específico
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                const detailedError = new Error(`Error de conexión: No se puede conectar al backend en ${this.baseURL}${API_CONFIG.ENDPOINTS.LOGIN}. Verificar que el backend esté ejecutándose en puerto 3000 y que CORS esté configurado para http://localhost:5173`);
                console.error('🔍 Diagnóstico:', detailedError.message);
                throw detailedError;
            }
            
            throw error;
        }
    }

    async logout() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay(200);
            localStorage.removeItem('authToken');
            localStorage.removeItem('user');
            return { success: true };
        }

        try {
            await this.makeRequest(API_CONFIG.ENDPOINTS.LOGOUT, {
                method: 'POST',
            });
        } finally {
            localStorage.removeItem('authToken');
            localStorage.removeItem('user');
        }
    }

    // === PRODUCTOS ===
    
    async getProductos() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            console.log('📦 Obteniendo productos mock:', MOCK_DATA.PRODUCTOS.length, 'productos');
            return MOCK_DATA.PRODUCTOS;
        }

        console.log('🌐 Obteniendo productos del backend real...');
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTOS);
            console.log('✅ Productos obtenidos del backend:', response);
            
            // Normalizar estructura de datos y nombres de campos
            let productos = [];
            if (Array.isArray(response)) {
                productos = response;
            } else if (response.data && Array.isArray(response.data)) {
                productos = response.data;
            } else if (response.productos && Array.isArray(response.productos)) {
                productos = response.productos;
            } else {
                console.warn('⚠️ Estructura de respuesta inesperada:', response);
                productos = response;
            }
            
            // SISTEMA ROBUSTO DE NORMALIZACIÓN DE IMÁGENES
            const productosNormalizados = productos.map(producto => {
                let productoNormalizado = { ...producto };
                
                // 1. Conversión estándar: imagenUrl → imagen_url
                if (producto.imagenUrl && !producto.imagen_url) {
                    console.log(`🔧 Normalizando imagenUrl → imagen_url para "${producto.nombre}":`, producto.imagenUrl);
                    productoNormalizado.imagen_url = producto.imagenUrl;
                }
                
                // 2. SISTEMA ROBUSTO: Recuperar desde cache si es necesario
                if ((!productoNormalizado.imagen_url || 
                     productoNormalizado.imagen_url === 'undefined' || 
                     productoNormalizado.imagen_url === 'null' ||
                     productoNormalizado.imagen_url === null) && 
                    ApiService.getProductImage(producto.id)) {
                    
                    const imagenUrlCache = ApiService.getProductImage(producto.id);
                    console.log(`💾 Recuperando imagen del cache persistente para "${producto.nombre}" (ID: ${producto.id}):`, imagenUrlCache);
                    productoNormalizado.imagen_url = imagenUrlCache;
                }
                
                // 3. DETECTAR Y REPORTAR PRODUCTOS PROBLEMÁTICOS
                if (productoNormalizado.imagen_url === 'undefined' || 
                    productoNormalizado.imagen_url === 'null' ||
                    productoNormalizado.imagen_url === undefined ||
                    productoNormalizado.imagen_url === null) {
                    console.log(`🚨 PRODUCTO CON IMAGEN PROBLEMÁTICA DETECTADO:`);
                    console.log(`   - Nombre: "${producto.nombre}"`);
                    console.log(`   - ID: ${producto.id}`);
                    console.log(`   - imagen_url: ${JSON.stringify(productoNormalizado.imagen_url)}`);
                    console.log(`   - imagenUrl original: ${JSON.stringify(producto.imagenUrl)}`);
                    console.log(`   - Cache disponible: ${!!ApiService.getProductImage(producto.id)}`);
                    
                    // Intentar recuperar URL de otros lugares
                    const camposAlternativos = [
                        producto.image_url,
                        producto.imageUrl,
                        producto.imagen,
                        producto.url_imagen
                    ];
                    
                    for (let i = 0; i < camposAlternativos.length; i++) {
                        const campo = camposAlternativos[i];
                        if (campo && campo !== 'undefined' && campo !== 'null') {
                            console.log(`🔧 URL alternativa encontrada en campo ${i + 1}:`, campo);
                            productoNormalizado.imagen_url = campo;
                            // Guardar en cache para futuras consultas
                            ApiService.setProductImage(producto.id, campo);
                            break;
                        }
                    }
                }
                
                return productoNormalizado;
            });
            
            console.log('📊 Productos normalizados:', productosNormalizados.length, 'productos');
            return productosNormalizados;
        } catch (error) {
            console.error('❌ Error al obtener productos del backend:', error);
            throw error;
        }
    }

    async getProductoById(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const producto = MOCK_DATA.PRODUCTOS.find(p => p.id === parseInt(id));
            if (!producto) {
                throw new Error('Producto no encontrado');
            }
            return producto;
        }

        return await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTO_BY_ID(id));
    }

    // SISTEMA ROBUSTO DE GESTIÓN DE IMÁGENES
    static productImageCache = new Map();
    static CACHE_KEY = 'kebumy_product_images';

    // Inicializar sistema robusto de imágenes
    static initializeImageCache() {
        try {
            const savedCache = localStorage.getItem(this.CACHE_KEY);
            if (savedCache) {
                const cacheData = JSON.parse(savedCache);
                this.productImageCache = new Map(cacheData);
                console.log('💾 Cache de imágenes cargado desde localStorage:', this.productImageCache.size, 'entradas');
                
                // Debug: Mostrar contenido del cache
                if (this.productImageCache.size > 0) {
                    console.log('🔍 Contenido del cache:', Array.from(this.productImageCache.entries()));
                }
            } else {
                console.log('💾 No hay cache previo en localStorage, iniciando cache vacío');
            }
        } catch (error) {
            console.error('❌ Error cargando cache de imágenes:', error);
            this.productImageCache = new Map();
        }
    }

    // Guardar cache en localStorage
    static saveImageCache() {
        try {
            const cacheArray = Array.from(this.productImageCache.entries());
            localStorage.setItem(this.CACHE_KEY, JSON.stringify(cacheArray));
            console.log('💾 Cache de imágenes guardado:', cacheArray.length, 'entradas');
        } catch (error) {
            console.error('❌ Error guardando cache de imágenes:', error);
        }
    }

    // Agregar imagen al cache
    static setProductImage(productId, imageUrl, metadata = {}) {
        const cacheEntry = {
            url: imageUrl,
            timestamp: Date.now(),
            ...metadata
        };
        this.productImageCache.set(productId, cacheEntry);
        this.saveImageCache();
        console.log(`🖼️ Imagen agregada al cache - ID: ${productId}, URL: ${imageUrl}`);
    }

    // Obtener imagen del cache
    static getProductImage(productId) {
        console.log(`🔍 Buscando en cache imagen para producto ID: ${productId}`);
        console.log(`📊 Estado actual del cache:`, {
            tamaño: this.productImageCache.size,
            tiene_id: this.productImageCache.has(productId),
            todas_las_entradas: Array.from(this.productImageCache.keys())
        });
        
        const cacheEntry = this.productImageCache.get(productId);
        if (cacheEntry) {
            console.log(`✅ Imagen encontrada en cache - ID: ${productId}, URL: ${cacheEntry.url || cacheEntry}`);
            return cacheEntry.url || cacheEntry; // Compatibilidad con formato antiguo
        }
        
        console.log(`❌ No se encontró imagen en cache para ID: ${productId}`);
        return null;
    }

    // Limpiar entradas viejas del cache (más de 30 días)
    static cleanImageCache() {
        const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
        let cleaned = 0;
        
        for (const [id, entry] of this.productImageCache.entries()) {
            if (entry.timestamp < thirtyDaysAgo) {
                this.productImageCache.delete(id);
                cleaned++;
            }
        }
        
        if (cleaned > 0) {
            this.saveImageCache();
            console.log(`🧹 Cache limpiado: ${cleaned} entradas removidas`);
        }
    }

    async createProducto(productoData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const nuevoProducto = {
                ...productoData,
                id: Math.max(...MOCK_DATA.PRODUCTOS.map(p => p.id)) + 1,
                fecha_creacion: new Date().toISOString().split('T')[0],
                estado: 'activo'
            };
            MOCK_DATA.PRODUCTOS.push(nuevoProducto);
            console.log('✅ Producto creado en modo mock:', nuevoProducto);
            return nuevoProducto;
        }

        console.log('🌐 Creando producto en backend real:', productoData);
        console.log('🖼️ Datos de imagen enviados al backend:', {
            imagen_url: productoData.imagen_url,
            tipo_imagen_url: typeof productoData.imagen_url,
            longitud_imagen_url: productoData.imagen_url?.length,
            es_url_externa: productoData.imagen_url?.startsWith('http'),
            todos_los_campos_imagen: Object.keys(productoData).filter(key => 
                key.toLowerCase().includes('imagen') || key.toLowerCase().includes('image')
            )
        });
        
        // PRESERVAR DATOS DE IMAGEN ORIGINAL
        const imagenOriginal = {
            url: productoData.imagen_url,
            tipo: productoData.imagen_url?.startsWith('http') ? 'url_externa' : 
                  productoData.imagen_url?.startsWith('img/') ? 'imagen_db' : 
                  productoData.imagen_url?.startsWith('upload') ? 'archivo_subido' : 'desconocido',
            timestamp: Date.now()
        };
        
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTOS, {
                method: 'POST',
                body: JSON.stringify(productoData),
            });
            console.log('✅ Producto creado en backend real:', response);
            console.log('🔍 Campo imagen_url en respuesta del backend:', {
                imagen_url: response.imagen_url,
                imagenUrl: response.imagenUrl,
                tipo_imagen_url: typeof response.imagen_url,
                tipo_imagenUrl: typeof response.imagenUrl
            });
            
            // SISTEMA ROBUSTO: Garantizar que la imagen se preserve
            if (imagenOriginal.url && response.id) {
                const imagenEnRespuesta = response.imagen_url || response.imagenUrl;
                
                if (!imagenEnRespuesta || 
                    imagenEnRespuesta === 'undefined' || 
                    imagenEnRespuesta === 'null' ||
                    imagenEnRespuesta !== imagenOriginal.url) {
                    
                    console.log('🔧 APLICANDO SOLUCIÓN ROBUSTA DE IMÁGENES');
                    console.log(`💾 Guardando imagen en cache persistente: ID ${response.id} → ${imagenOriginal.url}`);
                    
                    // Guardar en cache persistente
                    ApiService.setProductImage(response.id, imagenOriginal.url, {
                        tipo: imagenOriginal.tipo,
                        origen: 'formulario_creacion',
                        backend_fallo: true
                    });
                    
                    // Asegurar que la respuesta incluya la imagen
                    response.imagen_url = imagenOriginal.url;
                } else {
                    console.log('✅ Backend guardó correctamente la imagen_url');
                }
            }
            
            return response;
        } catch (error) {
            console.error('❌ Error al crear producto en backend:', error);
            throw error;
        }
    }

    async updateProducto(id, productoData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.PRODUCTOS.findIndex(p => p.id === parseInt(id));
            if (index === -1) {
                throw new Error('Producto no encontrado');
            }
            MOCK_DATA.PRODUCTOS[index] = { ...MOCK_DATA.PRODUCTOS[index], ...productoData };
            return MOCK_DATA.PRODUCTOS[index];
        }

        return await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTO_BY_ID(id), {
            method: 'PUT',
            body: JSON.stringify(productoData),
        });
    }

    async deleteProducto(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.PRODUCTOS.findIndex(p => p.id === parseInt(id));
            if (index === -1) {
                throw new Error('Producto no encontrado');
            }
            const deletedProduct = MOCK_DATA.PRODUCTOS.splice(index, 1)[0];
            console.log('✅ Producto eliminado en modo mock:', deletedProduct);
            return { success: true };
        }

        console.log('🌐 Eliminando producto del backend real:', id);
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTO_BY_ID(id), {
                method: 'DELETE',
            });
            console.log('✅ Producto eliminado del backend real:', response);
            return response;
        } catch (error) {
            console.error('❌ Error al eliminar producto del backend:', error);
            throw error;
        }
    }

    // === UPLOAD DE IMÁGENES ===
    
    async uploadImagen(formData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay(1000); // Simular upload más lento
            
            // Simular respuesta de upload
            const fileName = formData.get('imagen')?.name || 'imagen.jpg';
            const simulatedUrl = `uploads/productos/${Date.now()}_${fileName}`;
            
            console.log('📤 Simulando upload de imagen:', fileName);
            console.log('✅ URL simulada generada:', simulatedUrl);
            
            return {
                success: true,
                url: simulatedUrl,
                fileName: fileName
            };
        }

        console.log('📤 Subiendo imagen al backend real...');
        
        try {
            // Para upload de archivos, no usar JSON headers
            const config = {
                method: 'POST',
                mode: 'cors',
                credentials: 'omit',
                body: formData // No convertir a JSON, enviar FormData directamente
            };

            // Agregar token de autenticación si existe
            const token = localStorage.getItem('authToken');
            if (token) {
                config.headers = {
                    'Authorization': `Bearer ${token}`
                };
            }

            console.log('🌐 Haciendo petición de upload a:', `${this.baseURL}/upload/imagen`);
            
            const response = await fetch(`${this.baseURL}/upload/imagen`, config);
            
            console.log('📥 Respuesta de upload recibida:', { status: response.status });
            
            if (!response.ok) {
                const errorText = await response.text().catch(() => 'Error desconocido');
                throw new Error(`Error ${response.status}: ${errorText}`);
            }

            const result = await response.json();
            console.log('✅ Imagen subida exitosamente:', result);
            
            return result;
        } catch (error) {
            console.error('❌ Error al subir imagen:', error);
            throw error;
        }
    }

    // === USUARIOS ===
    
    async getUsuarios() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            return MOCK_DATA.USUARIOS;
        }

        console.log('🔍 Intentando obtener usuarios desde:', `${this.baseURL}/usuarios`);
        
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIOS);
            console.log('✅ Usuarios obtenidos correctamente:', response);
            return response;
        } catch (error) {
            console.error('❌ Error al obtener usuarios:', error);
            console.error('🔧 Detalles:', {
                endpoint: `${this.baseURL}${API_CONFIG.ENDPOINTS.USUARIOS}`,
                method: 'GET',
                useRealBackend: this.useRealBackend
            });
            throw error;
        }
    }

    async getUsuarioById(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const usuario = MOCK_DATA.USUARIOS.find(u => u.id === parseInt(id));
            if (!usuario) {
                throw new Error('Usuario no encontrado');
            }
            return usuario;
        }

        return await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIO_BY_ID(id));
    }

    async createUsuario(usuarioData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            console.log('👤 Creando usuario mock con datos:', usuarioData);
            
            const nuevoUsuario = {
                ...usuarioData,
                id: Math.max(...MOCK_DATA.USUARIOS.map(u => u.id)) + 1,
                fecha_creacion: new Date().toISOString().split('T')[0],
                ultimoAcceso: null,
                // Mantener el formato correcto del estado (minúsculas)
                estado: usuarioData.estado || 'activo'
            };
            
            MOCK_DATA.USUARIOS.push(nuevoUsuario);
            console.log('✅ Usuario mock creado:', nuevoUsuario);
            console.log('📊 Total usuarios mock:', MOCK_DATA.USUARIOS.length);
            
            return nuevoUsuario;
        }

        console.log('🌐 Creando usuario en backend real:', usuarioData);
        
        return await this.makeRequest(API_CONFIG.ENDPOINTS.CREAR_USUARIO_ADMIN, {
            method: 'POST',
            body: JSON.stringify(usuarioData),
        });
    }

    async updateUsuario(id, usuarioData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.USUARIOS.findIndex(u => u.id === parseInt(id));
            if (index === -1) {
                throw new Error('Usuario no encontrado');
            }
            
            console.log('🔄 Actualizando usuario mock:', id, usuarioData);
            
            // Actualizar el usuario manteniendo el formato correcto
            const usuarioActualizado = { 
                ...MOCK_DATA.USUARIOS[index], 
                ...usuarioData,
                // Mantener campos que no se deben cambiar
                id: MOCK_DATA.USUARIOS[index].id,
                fecha_creacion: MOCK_DATA.USUARIOS[index].fecha_creacion
            };
            
            MOCK_DATA.USUARIOS[index] = usuarioActualizado;
            console.log('✅ Usuario mock actualizado:', usuarioActualizado);
            
            return usuarioActualizado;
        }

        console.log('🌐 Actualizando usuario en backend real:', id, usuarioData);
        
        return await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIO_BY_ID(id), {
            method: 'PUT',
            body: JSON.stringify(usuarioData),
        });
    }

    async deleteUsuario(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.USUARIOS.findIndex(u => u.id === parseInt(id));
            if (index === -1) {
                throw new Error('Usuario no encontrado');
            }
            
            console.log('🗑️ Inhabilitando usuario mock:', id);
            
            // En lugar de eliminar, marcar como inactivo (formato correcto)
            MOCK_DATA.USUARIOS[index].estado = 'inactivo';
            
            console.log('✅ Usuario inhabilitado:', MOCK_DATA.USUARIOS[index]);
            
            return { success: true };
        }

        console.log('🌐 Inhabilitando usuario en backend real:', id);
        
        return await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIO_BY_ID(id), {
            method: 'DELETE',
        });
    }

    // === CONFIGURACIÓN ===
    
    // Método para cambiar entre modo desarrollo y producción
    setBackendMode(useRealBackend) {
        this.useRealBackend = useRealBackend;
        // Guardar en localStorage para persistencia
        localStorage.setItem('kebumy_backend_mode', JSON.stringify(useRealBackend));
        // Sincronizar con configuración global
        API_CONFIG.USE_REAL_BACKEND = useRealBackend;
        console.log(`🔄 Modo backend cambiado a: ${useRealBackend ? 'REAL (Puerto 3000)' : 'MOCK (Desarrollo)'}`);
    }

    // Verificar estado de conexión con el backend
    async checkBackendHealth() {
        if (!this.useRealBackend) {
            return { 
                status: 'OK', 
                mode: 'DESARROLLO',
                message: 'Usando datos mock para desarrollo'
            };
        }

        try {
            // Usar la URL específica de health check
            const healthUrl = API_CONFIG.HEALTH_CHECK_URL || `${this.baseURL}/health`;
            const response = await fetch(healthUrl, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                },
                mode: 'cors',
            });

            if (response.ok) {
                const data = await response.json();
                return {
                    status: data.status || 'OK',
                    mode: 'PRODUCCIÓN',
                    message: data.message || 'Backend conectado correctamente',
                    backend_url: data.backend_url,
                    frontend_url: data.frontend_url,
                    timestamp: data.timestamp
                };
            } else {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
        } catch (error) {
            console.error('Error checking backend health:', error);
            
            return {
                status: 'ERROR',
                mode: 'PRODUCCIÓN',
                error: `No se puede conectar al backend: ${error.message}`,
                details: `Verifique que el health check esté disponible en ${API_CONFIG.HEALTH_CHECK_URL}`
            };
        }
    }

    // Método para probar la conexión básica
    async testConnection() {
        try {
            console.log('🔍 Iniciando test de conexión completa...');
            
            // 1. Probar health check
            const healthUrl = API_CONFIG.HEALTH_CHECK_URL || `${this.baseURL}/health`;
            console.log('1️⃣ Probando health check:', healthUrl);
            
            const healthResponse = await fetch(healthUrl, {
                method: 'GET',
                headers: { 'Accept': 'application/json' },
                mode: 'cors',
            });
            
            console.log('✅ Health check status:', healthResponse.status);
            const healthData = await healthResponse.json();
            console.log('✅ Health check response:', healthData);
            
            // 2. Probar endpoint de usuarios
            console.log('2️⃣ Probando endpoint usuarios:', `${this.baseURL}/usuarios`);
            
            const usuariosResponse = await fetch(`${this.baseURL}/usuarios`, {
                method: 'GET',
                headers: { 
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                mode: 'cors',
            });
            
            console.log('📊 Usuarios response status:', usuariosResponse.status);
            console.log('📊 Usuarios response headers:', [...usuariosResponse.headers.entries()]);
            
            if (usuariosResponse.ok) {
                const usuariosData = await usuariosResponse.json();
                console.log('✅ Usuarios data:', usuariosData);
                
                return {
                    healthCheck: healthData,
                    usuariosEndpoint: {
                        status: usuariosResponse.status,
                        data: usuariosData
                    },
                    message: '🎉 Conexión completa verificada correctamente'
                };
            } else {
                const errorText = await usuariosResponse.text().catch(() => 'No response body');
                console.error('❌ Error en endpoint usuarios:', errorText);
                
                return {
                    healthCheck: healthData,
                    usuariosEndpoint: {
                        status: usuariosResponse.status,
                        error: errorText
                    },
                    message: `⚠️ Health check OK, pero endpoint usuarios falló con status ${usuariosResponse.status}`
                };
            }
        } catch (error) {
            console.error('💥 Error general en test de conexión:', error);
            
            // Diagnosticar el tipo de error
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                return {
                    error: 'CORS o conexión rechazada',
                    details: 'El backend no permite conexiones desde este origen o no está disponible',
                    suggestion: 'Verificar configuración CORS para http://localhost:5173'
                };
            }
            
            throw error;
        }
    }

    // ==================== MÉTODOS PARA CATÁLOGO CLIENTE ====================
    
    // Obtener productos para el catálogo público (solo productos activos)
    async getProductosCatalogo(filtros = {}) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            // Simular filtros con datos mock
            let productos = MOCK_DATA.productos.filter(producto => 
                producto.stock > 0 // Solo productos con stock
            );

            // Aplicar filtros
            if (filtros.categoria && filtros.categoria !== 'todas') {
                productos = productos.filter(p => 
                    p.categoria.toLowerCase() === filtros.categoria.toLowerCase()
                );
            }

            if (filtros.busqueda) {
                const busqueda = filtros.busqueda.toLowerCase();
                productos = productos.filter(p => 
                    p.nombre.toLowerCase().includes(busqueda) ||
                    p.descripcion.toLowerCase().includes(busqueda)
                );
            }

            if (filtros.precioMin) {
                productos = productos.filter(p => p.precio >= filtros.precioMin);
            }

            if (filtros.precioMax) {
                productos = productos.filter(p => p.precio <= filtros.precioMax);
            }

            // Simular ordenamiento
            if (filtros.ordenar) {
                switch(filtros.ordenar) {
                    case 'precio_asc':
                        productos.sort((a, b) => a.precio - b.precio);
                        break;
                    case 'precio_desc':
                        productos.sort((a, b) => b.precio - a.precio);
                        break;
                    case 'nombre_asc':
                        productos.sort((a, b) => a.nombre.localeCompare(b.nombre));
                        break;
                    case 'nombre_desc':
                        productos.sort((a, b) => b.nombre.localeCompare(a.nombre));
                        break;
                }
            }

            console.log(`📦 Productos catálogo mock (${productos.length} encontrados):`, productos);
            return productos;
        }

        try {
            // Construir query string para filtros
            const queryParams = new URLSearchParams();
            if (filtros.categoria && filtros.categoria !== 'todas') {
                queryParams.append('categoria', filtros.categoria);
            }
            if (filtros.busqueda) {
                queryParams.append('busqueda', filtros.busqueda);
            }
            if (filtros.precioMin) {
                queryParams.append('precioMin', filtros.precioMin);
            }
            if (filtros.precioMax) {
                queryParams.append('precioMax', filtros.precioMax);
            }
            if (filtros.ordenar) {
                queryParams.append('ordenar', filtros.ordenar);
            }

            const url = `/productos/catalogo${queryParams.toString() ? `?${queryParams.toString()}` : ''}`;
            const data = await this.makeRequest(url, { skipAuth: true });
            
            console.log(`📦 Productos catálogo desde backend:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error obteniendo catálogo:', error);
            throw error;
        }
    }

    // Obtener categorías disponibles para filtros
    async getCategorias() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            const categorias = [...new Set(MOCK_DATA.productos.map(p => p.categoria))];
            console.log(`📂 Categorías mock:`, categorias);
            return categorias;
        }

        try {
            const data = await this.makeRequest('/productos/categorias', { skipAuth: true });
            console.log(`📂 Categorías desde backend:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error obteniendo categorías:', error);
            throw error;
        }
    }

    // Obtener detalles de un producto específico
    async getProductoDetalle(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            const producto = MOCK_DATA.productos.find(p => p.id === parseInt(id));
            if (!producto) {
                throw new Error('Producto no encontrado');
            }
            
            console.log(`🔍 Detalle producto mock:`, producto);
            return producto;
        }

        try {
            const data = await this.makeRequest(`/productos/${id}`, { skipAuth: true });
            console.log(`🔍 Detalle producto desde backend:`, data);
            return data;
        } catch (error) {
            console.error(`💥 Error obteniendo producto ${id}:`, error);
            throw error;
        }
    }

    // ==================== MÉTODOS PARA CARRITO ====================
    
    // Simular guardado de carrito en el backend (opcional)
    async guardarCarrito(carritoData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            console.log(`💾 Carrito guardado mock:`, carritoData);
            return { success: true, mensaje: 'Carrito guardado exitosamente' };
        }

        try {
            const data = await this.makeRequest('/carrito', {
                method: 'POST',
                body: JSON.stringify(carritoData)
            });
            
            console.log(`💾 Carrito guardado en backend:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error guardando carrito:', error);
            throw error;
        }
    }

    // ==================== MÉTODOS PARA PEDIDOS ====================
    
    // Crear un nuevo pedido
    async crearPedido(pedidoData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            const nuevoPedido = {
                id: `ORD-${Date.now()}`,
                ...pedidoData,
                fecha: new Date().toISOString(),
                estado: 'Procesando'
            };
            
            console.log(`📄 Pedido creado mock:`, nuevoPedido);
            return nuevoPedido;
        }

        try {
            const data = await this.makeRequest('/pedidos', {
                method: 'POST',
                body: JSON.stringify(pedidoData)
            });
            
            console.log(`📄 Pedido creado en backend:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error creando pedido:', error);
            throw error;
        }
    }

    // Obtener pedidos de un cliente
    async getPedidosCliente(clienteId) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            // Datos mock de pedidos
            const pedidosMock = [
                {
                    id: 'ORD-2024-001',
                    fecha: '2024-01-15T10:30:00Z',
                    estado: 'Entregado',
                    total: 89990,
                    subtotal: 78990,
                    envio: 5990,
                    descuento: 5000,
                    productos: [
                        {
                            id: 1,
                            nombre: 'Polera Oversize Beige',
                            categoria: 'Poleras',
                            precio: 29990,
                            cantidad: 2,
                            imagen: '/src/assets/polaroid2.avif'
                        }
                    ],
                    tracking: 'TR123456789'
                }
            ];
            
            console.log(`📋 Pedidos cliente mock:`, pedidosMock);
            return pedidosMock;
        }

        try {
            console.log(`🔍 Consultando pedidos para usuario ID: ${clienteId}`);
            console.log(`🌐 URL: /pedidos/usuario/${clienteId}`);
            const data = await this.makeRequest(`/pedidos/usuario/${clienteId}`);
            console.log(`📋 Respuesta RAW pedidos cliente:`, data);
            console.log(`📋 Tipo de respuesta:`, typeof data, Array.isArray(data));
            console.log(`📋 data.pedidos existe?:`, !!data.pedidos);
            
            const result = data.pedidos || data;
            console.log(`📦 Resultado final a retornar:`, result);
            console.log(`📊 Número de pedidos:`, Array.isArray(result) ? result.length : 'No es array');
            
            return result;
        } catch (error) {
            console.error(`💥 Error obteniendo pedidos cliente ${clienteId}:`, error);
            throw error;
        }
    }

    // ==================== MÉTODOS DE CARRITO BACKEND ====================
    
    // Obtener carrito del usuario
    async obtenerCarrito(usuarioId) {
        try {
            const data = await this.makeRequest(`/carrito/${usuarioId}`);
            console.log(`🛒 Carrito obtenido:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error obteniendo carrito:', error);
            throw error;
        }
    }

    // Agregar producto al carrito (backend)
    async agregarAlCarrito(usuarioId, productoId, cantidad = 1) {
        try {
            const data = await this.makeRequest(`/carrito/${usuarioId}/agregar`, {
                method: 'POST',
                body: JSON.stringify({ productoId, cantidad })
            });
            console.log(`✅ Producto agregado al carrito:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error agregando al carrito:', error);
            throw error;
        }
    }

    // Actualizar cantidad en carrito
    async actualizarCantidadCarrito(usuarioId, productoId, cantidad) {
        try {
            const data = await this.makeRequest(`/carrito/${usuarioId}/actualizar`, {
                method: 'PUT',
                body: JSON.stringify({ productoId, cantidad })
            });
            console.log(`✅ Cantidad actualizada:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error actualizando cantidad:', error);
            throw error;
        }
    }

    // Eliminar producto del carrito
    async eliminarDelCarrito(usuarioId, productoId) {
        try {
            const data = await this.makeRequest(`/carrito/${usuarioId}/eliminar/${productoId}`, {
                method: 'DELETE'
            });
            console.log(`✅ Producto eliminado del carrito:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error eliminando del carrito:', error);
            throw error;
        }
    }

    // Limpiar carrito
    async limpiarCarrito(usuarioId) {
        try {
            const data = await this.makeRequest(`/carrito/${usuarioId}/limpiar`, {
                method: 'DELETE'
            });
            console.log(`✅ Carrito limpiado:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error limpiando carrito:', error);
            throw error;
        }
    }

    // Sincronizar carrito del localStorage con backend
    async sincronizarCarrito(usuarioId, items) {
        try {
            const data = await this.makeRequest(`/carrito/${usuarioId}/sincronizar`, {
                method: 'POST',
                body: JSON.stringify({ items })
            });
            console.log(`✅ Carrito sincronizado:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error sincronizando carrito:', error);
            throw error;
        }
    }

    // ==================== MÉTODOS DE PEDIDOS BACKEND ====================
    
    // Crear pedido (SIN Stripe - versión simulada)
    async crearPedido(usuarioId, datosEnvio) {
        try {
            const data = await this.makeRequest('/pedidos/crear', {
                method: 'POST',
                body: JSON.stringify({ usuarioId, datosEnvio })
            });
            console.log(`✅ Pedido creado:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error creando pedido:', error);
            throw error;
        }
    }

    // Obtener pedido por ID
    async getPedidoPorId(pedidoId) {
        try {
            const data = await this.makeRequest(`/pedidos/${pedidoId}`, {
                method: 'GET'
            });
            console.log(`✅ Pedido obtenido:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error obteniendo pedido:', error);
            throw error;
        }
    }

    // Procesar pago simulado
    async procesarPago(pedidoId, metodoPago) {
        try {
            const data = await this.makeRequest(`/pedidos/${pedidoId}/pagar`, {
                method: 'POST',
                body: JSON.stringify({ metodoPago })
            });
            console.log(`✅ Pago procesado:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error procesando pago:', error);
            throw error;
        }
    }

    // Admin - Confirmar pedido
    async confirmarPedido(pedidoId) {
        try {
            const data = await this.makeRequest(`/pedidos/${pedidoId}/confirmar`, {
                method: 'POST'
            });
            console.log(`✅ Pedido confirmado:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error confirmando pedido:', error);
            throw error;
        }
    }

    // Admin - Cancelar pedido
    async cancelarPedido(pedidoId, motivo) {
        try {
            const data = await this.makeRequest(`/pedidos/${pedidoId}/cancelar`, {
                method: 'POST',
                body: JSON.stringify({ motivo })
            });
            console.log(`✅ Pedido cancelado:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error cancelando pedido:', error);
            throw error;
        }
    }

    // Admin - Obtener todos los pedidos
    async obtenerTodosPedidos(params = {}) {
        try {
            const queryParams = new URLSearchParams(params).toString();
            const url = `/pedidos/todos${queryParams ? '?' + queryParams : ''}`;
            const data = await this.makeRequest(url, {
                method: 'GET'
            });
            console.log(`✅ Pedidos obtenidos:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error obteniendo pedidos:', error);
            throw error;
        }
    }

    // Admin - Obtener pedidos pendientes
    async obtenerPedidosPendientes() {
        try {
            const data = await this.makeRequest('/pedidos/pendientes', {
                method: 'GET'
            });
            console.log(`✅ Pedidos pendientes obtenidos:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error obteniendo pedidos pendientes:', error);
            throw error;
        }
    }

    // Confirmar pago después del checkout de Stripe
    async confirmarPago(sessionId) {
        try {
            const data = await this.makeRequest('/pedidos/confirmar-pago', {
                method: 'POST',
                body: JSON.stringify({ sessionId })
            });
            console.log(`✅ Pago confirmado:`, data);
            return data;
        } catch (error) {
            console.error('💥 Error confirmando pago:', error);
            throw error;
        }
    }

    // Obtener pedido por número
    async obtenerPedidoPorNumero(numeroPedido) {
        try {
            const data = await this.makeRequest(`/pedidos/numero/${numeroPedido}`);
            console.log(`📦 Pedido obtenido:`, data);
            return data.pedido || data;
        } catch (error) {
            console.error('💥 Error obteniendo pedido:', error);
            throw error;
        }
    }
}

// Crear instancia única del servicio
const apiService = new ApiService();

export { ApiService }; // Exportar la clase para métodos estáticos
export default apiService;