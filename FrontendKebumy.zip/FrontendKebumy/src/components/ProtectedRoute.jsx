import { Navigate, useLocation } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

/**
 * ProtectedRoute - Componente para proteger rutas que requieren autenticación
 * @param {React.ReactNode} children - Componentes hijos a renderizar si está autenticado
 * @param {string|string[]} requiredRole - Rol(es) requerido(s) para acceder (opcional)
 * @param {string} redirectTo - Ruta a la que redirigir si no cumple requisitos (opcional)
 */
const ProtectedRoute = ({ children, requiredRole, redirectTo }) => {
  const { isAuthenticated, user, isTokenValid } = useAuth();
  const location = useLocation();

  // Verificar si el token es válido
  if (!isTokenValid()) {
    console.warn('⚠️ ProtectedRoute - Token inválido o expirado');
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Verificar si el usuario está autenticado
  if (!isAuthenticated) {
    console.warn('⚠️ ProtectedRoute - Usuario no autenticado');
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Si se requiere un rol específico, verificarlo
  if (requiredRole) {
    const userRole = user?.rol;
    const hasRequiredRole = Array.isArray(requiredRole) 
      ? requiredRole.includes(userRole) 
      : userRole === requiredRole;

    if (!hasRequiredRole) {
      console.warn(`⚠️ ProtectedRoute - Usuario no tiene el rol requerido. Rol actual: ${userRole}, Requerido: ${requiredRole}`);
      
      // Redirigir según el rol del usuario
      const defaultRedirect = userRole === 'cliente' ? '/catalogo' : '/admin-usuarios';
      return <Navigate to={redirectTo || defaultRedirect} replace />;
    }
  }

  // Usuario autenticado y con rol correcto
  return children;
};

export default ProtectedRoute;