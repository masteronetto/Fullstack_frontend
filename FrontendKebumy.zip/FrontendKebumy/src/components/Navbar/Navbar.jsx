import { Link, useNavigate, useLocation } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import CartWidget from '../Cliente/CartWidget/CartWidget';
import logoKebumy from '../../assets/logoKebumy.png';
import logoMenu from '../../assets/Logo_menu.png';
import logoInicioSesion from '../../assets/logo_inicio_sesion.png';

export function Navbar() {
  const { user, isAuthenticated, logout, isAdmin, isCliente } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/', { replace: true });
  };

  return (
    <>
      {/* Top Banner */}
      <div className="top-banner">
        Bienvenido a Kebumy - Diseños únicos para ocasiones especiales
        <a href="/contacto">Contáctanos</a>
      </div>
      
      {/* Main Navbar */}
      <nav className="navbar">
        {/* Logo */}
        <div className="logo-container">
          <Link to="/">
            <img src={logoKebumy} alt="Kebumy Logo" />
          </Link>
        </div>

        {/* Navigation Links */}
        <div className="navbar-links">
          <Link to="/">Inicio</Link>
          
          {/* Enlaces Admin (solo para admin y super-admin) */}
          {isAuthenticated && isAdmin() && (
            <>
              <Link to="/inventario">Inventario</Link>
              <Link to="/admin-usuarios">Usuarios</Link>
              <Link to="/gestion-pedidos">Gestión Pedidos</Link>
            </>
          )}
          
          {/* Enlaces Cliente (siempre visible) */}
          <Link to="/catalogo">Tienda</Link>
          
          {/* Opciones adicionales para clientes autenticados */}
          {isAuthenticated && isCliente() && (
            <>
              <Link to="/pedidos">Mis Pedidos</Link>
              <Link to="/mi-cuenta">Mi Cuenta</Link>
            </>
          )}
          
          <Link to="/contacto">Contacto</Link>
        </div>

        {/* Right Side Icons */}
        <div className="navbar-icons">
          {/* Cart Widget - solo visible para clientes */}
          {isAuthenticated && isCliente() && <CartWidget />}
          {!isAuthenticated && <CartWidget />}
          
          {/* Authentication Section */}
          {isAuthenticated ? (
            <>
              {/* Mostrar información del usuario según rol */}
              {isAdmin() ? (
                <span style={{ marginRight: '15px', color: '#b0417a', fontSize: '14px', fontWeight: '600' }}>
                  👤 Admin: {user.nombre || user.email}
                </span>
              ) : (
                <Link 
                  to="/mi-cuenta" 
                  style={{ 
                    marginRight: '15px', 
                    color: '#b0417a', 
                    fontSize: '14px',
                    textDecoration: 'none',
                    fontWeight: '600'
                  }}
                >
                  👤 Hola, {user.nombre || 'Cliente'}
                </Link>
              )}
              
              <button 
                onClick={handleLogout}
                style={{
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: '#b0417a',
                  fontSize: '14px',
                  textDecoration: 'underline',
                  fontWeight: '500'
                }}
              >
                Cerrar Sesión
              </button>
            </>
          ) : (
            <Link to="/login">
              <img 
                src={logoInicioSesion} 
                alt="Iniciar Sesión" 
                className="navbar-icon-img"
                title="Iniciar Sesión"
              />
            </Link>
          )}
          
          {/* Menu Toggle for Mobile */}
          <button className="menu-toggle-btn" style={{ display: 'none' }}>
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </nav>
    </>
  );
}