import React, { useState } from 'react';
import useCart from '../../../hooks/cliente/useCart';
import './ProductCard.css';

// Importar todas las imágenes necesarias
import PolerImg from '../../../assets/Polera.png';
import PoleronImg from '../../../assets/Poleron.png';
import AgendaImg from '../../../assets/Agenda.png';
import StickerImg from '../../../assets/sticker.png';
import PolaroidImg from '../../../assets/Polaroid.png';
import MiniCalendarioImg from '../../../assets/miniCalendario.png';
import PolerasMarcaImg from '../../../assets/PolerasMarca.png';
import TarjetaPresentacionImg from '../../../assets/TarjetaPresentacion2.jpeg';
import EtiquetaCueroImg from '../../../assets/etiquetaCuero.png';
import Sticker3Img from '../../../assets/Sticker3.png';
import KitCumpleanosImg from '../../../assets/KitCumpleaños.png';
import ImagenProducto1 from '../../../assets/imagen producto 1.webp';

const ProductCard = ({ producto, onViewDetails }) => {
  const { addToCart, isInCart, getItemQuantity } = useCart();
  const [isLoading, setIsLoading] = useState(false);
  const [imageError, setImageError] = useState(false);

  const handleAddToCart = async () => {
    setIsLoading(true);
    try {
      await addToCart(producto, 1);
      // Mostrar feedback visual
      setTimeout(() => setIsLoading(false), 500);
    } catch (error) {
      console.error('Error al agregar al carrito:', error);
      setIsLoading(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(price);
  };

  const getImageUrl = () => {
    if (imageError) {
      return '/placeholder.png';
    }
    
    const productName = producto.nombre || 'Sin nombre';
    const imagenUrl = producto.imagen_url || producto.imagenUrl;
    
    // Mapeo de imágenes locales importadas
    const imageMap = {
      'img/Polera.png': PolerImg,
      'img/Poleron.png': PoleronImg,
      'img/Agenda.png': AgendaImg,
      'img/sticker.png': StickerImg,
      'img/Polaroid.png': PolaroidImg,
      'img/miniCalendario.png': MiniCalendarioImg,
      'img/PolerasMarca.png': PolerasMarcaImg,
      'img/tarjetaPresentacion.png': TarjetaPresentacionImg,
      'img/etiquetaCuero.png': EtiquetaCueroImg,
      'img/stickerMarca.png': Sticker3Img,
      'img/Mochila.png': KitCumpleanosImg
    };
    
    // 🔍 PASO 1: Verificar URL válida
    let urlValida = null;
    
    if (imagenUrl && 
        imagenUrl !== 'undefined' && 
        imagenUrl !== 'null' && 
        typeof imagenUrl === 'string' &&
        imagenUrl.trim() !== '') {
      urlValida = imagenUrl;
    }
    
    // 🔍 PASO 2: Procesar URL válida
    if (urlValida) {
      // URL absoluta (externa)
      if (urlValida.startsWith('http://') || urlValida.startsWith('https://')) {
        return urlValida;
      }
      
      // Imagen local (img/...)
      if (urlValida.startsWith('img/')) {
        const mappedImage = imageMap[urlValida];
        if (mappedImage) {
          return mappedImage;
        }
      }
      
      // Imagen base64
      if (urlValida.startsWith('data:image/')) {
        return urlValida;
      }
      
      // Archivo subido (uploaded/...)
      if (urlValida.startsWith('uploaded/') || urlValida.startsWith('uploads/')) {
        return `http://localhost:3000/${urlValida}`;
      }
    }
    
    // 🔍 PASO 3: Mapeo inteligente como fallback
    const productLower = productName.toLowerCase();
    const smartMap = {
      'polera': PolerImg,
      'poleron': PoleronImg,
      'agenda': AgendaImg,
      'libreta': AgendaImg,
      'cuaderno': AgendaImg,
      'sticker': StickerImg,
      'adhesivo': StickerImg,
      'vinilo': StickerImg,
      'polaroid': PolaroidImg,
      'foto': PolaroidImg,
      'fotografia': PolaroidImg,
      'calendario': MiniCalendarioImg,
      'imantado': MiniCalendarioImg,
      'tarjeta': TarjetaPresentacionImg,
      'presentacion': TarjetaPresentacionImg,
      'business': TarjetaPresentacionImg,
      'etiqueta': EtiquetaCueroImg,
      'cuero': EtiquetaCueroImg,
      'mochila': KitCumpleanosImg,
      'kit': KitCumpleanosImg,
      'cumpleanos': KitCumpleanosImg
    };
    
    for (const [keyword, image] of Object.entries(smartMap)) {
      if (productLower.includes(keyword)) {
        return image;
      }
    }
    
    // 🔍 PASO 4: Imagen por defecto
    return ImagenProducto1;
  };

  const isOutOfStock = producto.stock <= 0;
  const isLowStock = producto.stock > 0 && producto.stock < 5;
  const itemQuantity = getItemQuantity(producto.id);

  return (
    <div className="product-card">
      <div className="product-image-container">
        <img
          src={getImageUrl()}
          alt={producto.nombre}
          className="product-image"
          onError={() => setImageError(true)}
          loading="lazy"
        />
        
        {isOutOfStock && (
          <div className="stock-overlay">
            <span>Agotado</span>
          </div>
        )}
        
        {isLowStock && (
          <div className="low-stock-badge">
            ¡Últimas {producto.stock} unidades!
          </div>
        )}
        
        {itemQuantity > 0 && (
          <div className="in-cart-badge">
            {itemQuantity} en carrito
          </div>
        )}
      </div>

      <div className="product-info">
        <div className="product-category">
          {producto.categoria_nombre || 'Producto'}
        </div>
        
        <h3 className="product-name" title={producto.nombre}>
          {producto.nombre}
        </h3>
        
        <p className="product-description">
          {producto.descripcion?.length > 100
            ? `${producto.descripcion.substring(0, 100)}...`
            : producto.descripcion
          }
        </p>
        
        <div className="product-price">
          <span className="current-price">
            {formatPrice(producto.precio)}
          </span>
        </div>
        
        <div className="product-stock">
          <span className={`stock-indicator ${isOutOfStock ? 'out-of-stock' : isLowStock ? 'low-stock' : 'in-stock'}`}>
            {isOutOfStock ? 'Sin stock' : `Stock: ${producto.stock}`}
          </span>
        </div>
      </div>

      <div className="product-actions">
        <button
          className={`btn-add-cart ${isOutOfStock ? 'disabled' : ''} ${isLoading ? 'loading' : ''}`}
          onClick={handleAddToCart}
          disabled={isOutOfStock || isLoading}
        >
          {isLoading ? (
            <span className="loading-spinner">⏳</span>
          ) : isOutOfStock ? (
            'Agotado'
          ) : itemQuantity > 0 ? (
            '+ Agregar más'
          ) : (
            'Agregar al carrito'
          )}
        </button>
      </div>
    </div>
  );
};

export default ProductCard;