import React from 'react';
import { useNavigate } from 'react-router-dom';
import useCart from '../../../hooks/cliente/useCart';
import './CartWidget.css';

const CartWidget = () => {
  const navigate = useNavigate();
  const { getTotalItems } = useCart();
  const totalItems = getTotalItems();

  const handleCartClick = () => {
    navigate('/carrito');
  };

  return (
    <div className="cart-widget">
      <button className="cart-trigger" onClick={handleCartClick}>
        🛒
        {totalItems > 0 && (
          <span className="cart-count">{totalItems}</span>
        )}
      </button>
    </div>
  );
};

export default CartWidget;