// src/pages/Register/Register.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import authService from '../../services/authService';
import logoKebumy from '../../assets/logoKebumy.png';
import './Register.css';

export default function Register() {
    // Estados del formulario
    const [formData, setFormData] = useState({
        nombre: '',
        email: '',
        password: '',
        confirmPassword: '',
        telefono: '',
        direccion: ''
    });
    
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);
    const [passwordErrors, setPasswordErrors] = useState([]);
    
    // Hooks
    const navigate = useNavigate();
    const location = useLocation();
    const { login, isAuthenticated, user } = useAuth();
    
    // Redirigir si ya está autenticado
    useEffect(() => {
        if (isAuthenticated && user) {
            const defaultPath = user.rol === 'admin' || user.rol === 'super-admin' 
                ? '/admin-usuarios' 
                : '/catalogo';
            
            navigate(defaultPath, { replace: true });
        }
    }, [isAuthenticated, user, navigate]);

    // Validar contraseña en tiempo real
    useEffect(() => {
        if (formData.password) {
            const errors = [];
            if (formData.password.length < 6) {
                errors.push('Mínimo 6 caracteres');
            }
            if (!/[A-Z]/.test(formData.password)) {
                errors.push('Al menos una mayúscula');
            }
            if (!/[a-z]/.test(formData.password)) {
                errors.push('Al menos una minúscula');
            }
            if (!/[0-9]/.test(formData.password)) {
                errors.push('Al menos un número');
            }
            setPasswordErrors(errors);
        } else {
            setPasswordErrors([]);
        }
    }, [formData.password]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        
        // Validaciones
        if (formData.password !== formData.confirmPassword) {
            setError('Las contraseñas no coinciden');
            setLoading(false);
            return;
        }

        if (passwordErrors.length > 0) {
            setError('La contraseña no cumple con los requisitos mínimos');
            setLoading(false);
            return;
        }

        console.log('📝 Iniciando proceso de registro...');
        
        // Preparar datos para enviar al backend
        const registroData = {
            nombre: formData.nombre,
            email: formData.email,
            password: formData.password,
            telefono: formData.telefono || undefined,
            direccion: formData.direccion || undefined
        };

        try {
            console.log('📤 Enviando datos de registro al backend...');
            
            // Usar authService para registro
            const response = await authService.register(registroData);
            
            console.log('✅ Registro exitoso, respuesta del backend:', response);
            console.log('👤 Usuario creado:', response.usuario);
            console.log('🎭 Rol asignado:', response.usuario?.rol);
            
            // Login automático después del registro exitoso
            const loginSuccess = login(response);
            
            if (loginSuccess) {
                console.log('🎯 Login automático exitoso después del registro');
                // El redirect se hará automáticamente por el useEffect
            } else {
                // Si falla el login automático, redirigir manualmente al login
                console.warn('⚠️ Login automático falló, redirigiendo a login...');
                navigate('/login', { 
                    state: { 
                        message: 'Registro exitoso. Por favor inicia sesión.',
                        email: formData.email
                    } 
                });
            }

        } catch (err) {
            console.error('❌ Registro Fallido:', err);
            setError(err.message || 'Error al registrar usuario. Inténtalo nuevamente.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="register-container">
            <div className="register-box">
                {/* Logo de Kebumy */}
                <div style={{ textAlign: 'center', marginBottom: '30px' }}>
                    <img 
                        src={logoKebumy} 
                        alt="Kebumy Logo" 
                        style={{ width: '200px', marginBottom: '20px' }}
                    />
                    <h3 style={{ margin: '0', color: '#555' }}>Crear Cuenta</h3>
                    <p style={{ margin: '10px 0 0 0', color: '#888', fontSize: '14px' }}>
                        Regístrate para comenzar
                    </p>
                </div>
                
                {/* Muestra el error si existe */}
                {error && (
                    <div className="alert alert-error">
                        {error}
                    </div>
                )}
                
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="nombre">
                            Nombre Completo <span className="required">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="nombre" 
                            name="nombre"
                            value={formData.nombre}
                            onChange={handleChange} 
                            required 
                            disabled={loading}
                            placeholder="Juan Pérez"
                        />
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="email">
                            Email <span className="required">*</span>
                        </label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email"
                            value={formData.email}
                            onChange={handleChange} 
                            required 
                            disabled={loading}
                            placeholder="tu@email.com"
                        />
                    </div>
                    
                    <div className="form-row">
                        <div className="form-group">
                            <label htmlFor="password">
                                Contraseña <span className="required">*</span>
                            </label>
                            <input 
                                type="password" 
                                id="password" 
                                name="password"
                                value={formData.password}
                                onChange={handleChange} 
                                required 
                                disabled={loading}
                                placeholder="Contraseña segura"
                            />
                            {passwordErrors.length > 0 && formData.password && (
                                <div className="password-requirements">
                                    {passwordErrors.map((err, idx) => (
                                        <small key={idx} className="text-danger">• {err}</small>
                                    ))}
                                </div>
                            )}
                        </div>
                        
                        <div className="form-group">
                            <label htmlFor="confirmPassword">
                                Confirmar Contraseña <span className="required">*</span>
                            </label>
                            <input 
                                type="password" 
                                id="confirmPassword" 
                                name="confirmPassword"
                                value={formData.confirmPassword}
                                onChange={handleChange} 
                                required 
                                disabled={loading}
                                placeholder="Repite tu contraseña"
                            />
                            {formData.confirmPassword && formData.password !== formData.confirmPassword && (
                                <small className="text-danger">Las contraseñas no coinciden</small>
                            )}
                        </div>
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="telefono">
                            Teléfono <span className="optional">(opcional)</span>
                        </label>
                        <input 
                            type="tel" 
                            id="telefono" 
                            name="telefono"
                            value={formData.telefono}
                            onChange={handleChange} 
                            disabled={loading}
                            placeholder="+56 9 1234 5678"
                        />
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="direccion">
                            Dirección <span className="optional">(opcional)</span>
                        </label>
                        <input 
                            type="text" 
                            id="direccion" 
                            name="direccion"
                            value={formData.direccion}
                            onChange={handleChange} 
                            disabled={loading}
                            placeholder="Calle 123, Ciudad"
                        />
                    </div>
                    
                    <button 
                        type="submit" 
                        className="submit-button" 
                        disabled={loading || passwordErrors.length > 0}
                    >
                        {loading ? '📝 Creando cuenta...' : '🚀 Registrarse'}
                    </button>
                    
                    <div className="login-link">
                        ¿Ya tienes cuenta? <Link to="/login">Inicia sesión aquí</Link>
                    </div>
                </form>
            </div>
        </div>
    );
}
