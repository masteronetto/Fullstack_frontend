import React, { useState, useEffect } from 'react';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import apiService from '../../../services/apiService';
import './GestionPedidos.css';

const GestionPedidos = () => {
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filtroEstado, setFiltroEstado] = useState('todos');
  const [pedidoSeleccionado, setPedidoSeleccionado] = useState(null);
  const [mostrarModal, setMostrarModal] = useState(false);
  const [accionModal, setAccionModal] = useState(null); // 'confirmar' o 'cancelar'
  const [motivoCancelacion, setMotivoCancelacion] = useState('');
  const [procesando, setProcesando] = useState(false);

  useEffect(() => {
    cargarPedidos();
  }, [filtroEstado]);

  const cargarPedidos = async () => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('📋 Cargando todos los pedidos (Admin)...');
      const params = filtroEstado !== 'todos' ? { estado: filtroEstado } : {};
      const response = await apiService.obtenerTodosPedidos(params);
      
      console.log('✅ Pedidos cargados:', response);
      const pedidosData = response.pedidos || response;
      
      // Logging detallado de estados
      if (Array.isArray(pedidosData)) {
        console.log('📊 Total de pedidos:', pedidosData.length);
        pedidosData.forEach((p, idx) => {
          console.log(`Pedido ${idx + 1}:`, {
            id: p.id,
            estado: p.estado,
            estadoType: typeof p.estado,
            estadoPago: p.estadoPago,
            estadoPedido: p.estadoPedido,
            pagado: p.pagado,
            confirmado: p.confirmado,
            cancelado: p.cancelado,
            usuario: p.usuario?.nombre || p.nombreUsuario,
            allKeys: Object.keys(p)
          });
        });
      }
      
      setPedidos(Array.isArray(pedidosData) ? pedidosData : []);
    } catch (error) {
      console.error('❌ Error al cargar pedidos:', error);
      setError('No se pudieron cargar los pedidos');
      setPedidos([]);
    } finally {
      setLoading(false);
    }
  };

  const abrirModal = (pedido, accion) => {
    setPedidoSeleccionado(pedido);
    setAccionModal(accion);
    setMostrarModal(true);
    setMotivoCancelacion('');
  };

  const cerrarModal = () => {
    setMostrarModal(false);
    setPedidoSeleccionado(null);
    setAccionModal(null);
    setMotivoCancelacion('');
  };

  const confirmarPedido = async () => {
    if (!pedidoSeleccionado) return;

    setProcesando(true);
    try {
      console.log(`✅ Confirmando pedido ${pedidoSeleccionado.id}...`);
      await apiService.confirmarPedido(pedidoSeleccionado.id);
      
      // Actualizar el pedido en la lista
      setPedidos(pedidos.map(p => 
        p.id === pedidoSeleccionado.id 
          ? { ...p, estado: 'confirmado' }
          : p
      ));
      
      cerrarModal();
      alert('✅ Pedido confirmado exitosamente');
    } catch (error) {
      console.error('❌ Error al confirmar pedido:', error);
      alert('Error al confirmar el pedido: ' + error.message);
    } finally {
      setProcesando(false);
    }
  };

  const cancelarPedido = async () => {
    if (!pedidoSeleccionado || !motivoCancelacion.trim()) {
      alert('Por favor ingresa un motivo de cancelación');
      return;
    }

    setProcesando(true);
    try {
      console.log(`❌ Cancelando pedido ${pedidoSeleccionado.id}...`);
      await apiService.cancelarPedido(pedidoSeleccionado.id, motivoCancelacion);
      
      // Actualizar el pedido en la lista
      setPedidos(pedidos.map(p => 
        p.id === pedidoSeleccionado.id 
          ? { ...p, estado: 'cancelado', motivoCancelacion }
          : p
      ));
      
      cerrarModal();
      alert('❌ Pedido cancelado exitosamente');
    } catch (error) {
      console.error('❌ Error al cancelar pedido:', error);
      alert('Error al cancelar el pedido: ' + error.message);
    } finally {
      setProcesando(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(price);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Fecha no disponible';
    return new Date(dateString).toLocaleDateString('es-CL', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getEstadoBadge = (estado) => {
    const estados = {
      'pendiente': { color: '#ffc107', label: 'Pendiente', icon: '⏳' },
      'pagado': { color: '#17a2b8', label: 'Pagado', icon: '💳' },
      'confirmado': { color: '#28a745', label: 'Confirmado', icon: '✅' },
      'procesando': { color: '#007bff', label: 'Procesando', icon: '📦' },
      'enviado': { color: '#6f42c1', label: 'Enviado', icon: '🚚' },
      'entregado': { color: '#20c997', label: 'Entregado', icon: '🎉' },
      'cancelado': { color: '#dc3545', label: 'Cancelado', icon: '❌' },
      // Variantes alternativas
      'pending': { color: '#ffc107', label: 'Pendiente', icon: '⏳' },
      'paid': { color: '#17a2b8', label: 'Pagado', icon: '💳' },
      'confirmed': { color: '#28a745', label: 'Confirmado', icon: '✅' },
      'cancelled': { color: '#dc3545', label: 'Cancelado', icon: '❌' }
    };
    
    const estadoKey = estado?.toLowerCase();
    const estadoInfo = estados[estadoKey] || { 
      color: '#6c757d', 
      label: estado || 'Sin estado', 
      icon: '❓' 
    };
    
    // Log si el estado no es reconocido
    if (!estados[estadoKey] && estado) {
      console.warn('⚠️ Estado no reconocido:', estado);
    }
    
    return (
      <span className="estado-badge" style={{ backgroundColor: estadoInfo.color }}>
        {estadoInfo.icon} {estadoInfo.label}
      </span>
    );
  };

  const puedeConfirmar = (pedido) => {
    // Puede confirmar si el pago está confirmado y el pedido está pendiente
    return pedido.estadoPago === 'pagado' && pedido.estadoPedido?.toLowerCase() === 'pendiente';
  };

  const puedeCancelar = (pedido) => {
    const estadosCancelables = ['pendiente', 'confirmado', 'procesando'];
    return estadosCancelables.includes(pedido.estadoPedido?.toLowerCase());
  };

  if (loading) {
    return (
      <div className="gestion-pedidos-page">
        <Navbar />
        <div className="gestion-container">
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Cargando pedidos...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="gestion-pedidos-page">
      <Navbar />
      
      <div className="gestion-container">
        <div className="gestion-header">
          <div>
            <h1>📦 Gestión de Pedidos</h1>
            <p>Administrar y procesar pedidos de clientes</p>
          </div>
          <button onClick={cargarPedidos} className="btn-recargar" disabled={loading}>
            {loading ? '🔄 Cargando...' : '🔄 Actualizar'}
          </button>
        </div>

        {/* Filtros */}
        <div className="filtros-container">
          <button 
            className={`filtro-btn ${filtroEstado === 'todos' ? 'active' : ''}`}
            onClick={() => setFiltroEstado('todos')}
          >
            Todos ({pedidos.length})
          </button>
          <button 
            className={`filtro-btn ${filtroEstado === 'pendiente' ? 'active' : ''}`}
            onClick={() => setFiltroEstado('pendiente')}
          >
            ⏳ Pendientes
          </button>
          <button 
            className={`filtro-btn ${filtroEstado === 'pagado' ? 'active' : ''}`}
            onClick={() => setFiltroEstado('pagado')}
          >
            💳 Pagados
          </button>
          <button 
            className={`filtro-btn ${filtroEstado === 'confirmado' ? 'active' : ''}`}
            onClick={() => setFiltroEstado('confirmado')}
          >
            ✅ Confirmados
          </button>
          <button 
            className={`filtro-btn ${filtroEstado === 'cancelado' ? 'active' : ''}`}
            onClick={() => setFiltroEstado('cancelado')}
          >
            ❌ Cancelados
          </button>
        </div>

        {error && (
          <div className="error-message">
            <p>⚠️ {error}</p>
            <button onClick={cargarPedidos} className="btn-retry">Reintentar</button>
          </div>
        )}

        {pedidos.length === 0 ? (
          <div className="pedidos-empty">
            <div className="empty-icon">📦</div>
            <h2>No hay pedidos</h2>
            <p>No se encontraron pedidos con los filtros seleccionados</p>
          </div>
        ) : (
          <div className="pedidos-lista">
            {pedidos.map((pedido) => (
              <div key={pedido.id} className="pedido-admin-card">
                <div className="pedido-admin-header">
                  <div className="pedido-info-principal">
                    <h3>Pedido #{pedido.id}</h3>
                    {getEstadoBadge(pedido.estadoPedido || pedido.estado)}
                    {pedido.estadoPago && pedido.estadoPago === 'pagado' && (
                      <span className="badge-pago-ok" style={{ backgroundColor: '#28a745', color: 'white', padding: '4px 10px', borderRadius: '12px', fontSize: '12px', marginLeft: '8px' }}>
                        💵 Pago confirmado
                      </span>
                    )}
                  </div>
                  <div className="pedido-fecha">
                    📅 {formatDate(pedido.fechaCreacion || pedido.fecha)}
                  </div>
                </div>

                <div className="pedido-admin-body">
                  {/* Información del Cliente */}
                  <div className="info-section">
                    <h4>👤 Cliente</h4>
                    <p><strong>Nombre:</strong> {pedido.usuario?.nombre || pedido.nombreUsuario || 'N/A'}</p>
                    <p><strong>Email:</strong> {pedido.usuario?.email || pedido.emailUsuario || 'N/A'}</p>
                    <p><strong>Teléfono:</strong> {pedido.telefono || pedido.usuario?.telefono || 'N/A'}</p>
                  </div>

                  {/* Dirección de Envío */}
                  <div className="info-section">
                    <h4>📍 Dirección de Envío</h4>
                    <p>{pedido.direccionEnvio || 'No especificada'}</p>
                    {pedido.ciudad && <p>{pedido.ciudad}, {pedido.region}</p>}
                  </div>

                  {/* Productos */}
                  <div className="info-section">
                    <h4>📦 Productos ({pedido.items?.length || 0})</h4>
                    <div className="productos-mini-lista">
                      {pedido.items?.map((item, index) => (
                        <div key={index} className="producto-mini">
                          <span className="producto-nombre">{item.nombreProducto || item.nombre}</span>
                          <span className="producto-cantidad">x{item.cantidad}</span>
                          <span className="producto-precio">{formatPrice(item.subtotal || item.precio * item.cantidad)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Totales */}
                  <div className="info-section totales">
                    <div className="total-row">
                      <span>Subtotal:</span>
                      <span>{formatPrice(pedido.subtotal)}</span>
                    </div>
                    <div className="total-row">
                      <span>Envío:</span>
                      <span>{formatPrice(pedido.envio || 5000)}</span>
                    </div>
                    <div className="total-row final">
                      <span>Total:</span>
                      <span>{formatPrice(pedido.total)}</span>
                    </div>
                  </div>

                  {/* Método de Pago */}
                  <div className="info-section">
                    <h4>💳 Método de Pago</h4>
                    <p className="metodo-pago">
                      {pedido.metodoPago === 'tarjeta' && '💳 Tarjeta de Crédito/Débito'}
                      {pedido.metodoPago === 'paypal' && '🅿️ PayPal'}
                      {pedido.metodoPago === 'webpay' && '🇨🇱 Webpay'}
                      {!pedido.metodoPago && 'No especificado'}
                    </p>
                  </div>
                </div>

                {/* Acciones */}
                <div className="pedido-admin-actions">
                  {puedeConfirmar(pedido) && (
                    <button 
                      className="btn-confirmar"
                      onClick={() => abrirModal(pedido, 'confirmar')}
                    >
                      ✅ Confirmar Pedido
                    </button>
                  )}
                  {puedeCancelar(pedido) && (
                    <button 
                      className="btn-cancelar"
                      onClick={() => abrirModal(pedido, 'cancelar')}
                    >
                      ❌ Cancelar Pedido
                    </button>
                  )}
                  {!puedeConfirmar(pedido) && !puedeCancelar(pedido) && (
                    <span className="no-actions">Sin acciones disponibles</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal de Confirmación */}
      {mostrarModal && (
        <div className="modal-overlay" onClick={cerrarModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>
              {accionModal === 'confirmar' ? '✅ Confirmar Pedido' : '❌ Cancelar Pedido'}
            </h2>
            
            <p>
              ¿Estás seguro de {accionModal === 'confirmar' ? 'confirmar' : 'cancelar'} el pedido <strong>#{pedidoSeleccionado?.id}</strong>?
            </p>

            {accionModal === 'cancelar' && (
              <div className="form-group">
                <label>Motivo de cancelación *</label>
                <textarea
                  value={motivoCancelacion}
                  onChange={(e) => setMotivoCancelacion(e.target.value)}
                  placeholder="Ingresa el motivo de la cancelación..."
                  rows="4"
                  required
                />
              </div>
            )}

            <div className="modal-actions">
              <button 
                className="btn-secondary"
                onClick={cerrarModal}
                disabled={procesando}
              >
                Cancelar
              </button>
              <button 
                className={accionModal === 'confirmar' ? 'btn-confirmar' : 'btn-cancelar'}
                onClick={accionModal === 'confirmar' ? confirmarPedido : cancelarPedido}
                disabled={procesando}
              >
                {procesando ? 'Procesando...' : (accionModal === 'confirmar' ? 'Confirmar' : 'Cancelar Pedido')}
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};

export default GestionPedidos;
