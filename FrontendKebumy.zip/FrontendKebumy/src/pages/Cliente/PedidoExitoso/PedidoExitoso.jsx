import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import apiService from '../../../services/apiService';
import './PedidoExitoso.css';

const PedidoExitoso = () => {
  const { pedidoId } = useParams();
  const [pedido, setPedido] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarPedido();
  }, [pedidoId]);

  const cargarPedido = async () => {
    try {
      const response = await apiService.getPedidoPorId(pedidoId);
      setPedido(response.pedido || response);
    } catch (error) {
      console.error('Error cargando pedido:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(price);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Fecha no disponible';
    return new Date(dateString).toLocaleDateString('es-CL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="pedido-exitoso-page">
        <Navbar />
        <div className="pedido-exitoso-container">
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Cargando información...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="pedido-exitoso-page">
      <Navbar />
      
      <div className="pedido-exitoso-container">
        <div className="success-card">
          <div className="success-icon">✅</div>
          <h1>¡Pedido Realizado con Éxito!</h1>
          <p className="success-message">
            Tu pago ha sido procesado correctamente. Recibirás un correo con los detalles de tu pedido.
          </p>

          {pedido && (
            <>
              <div className="pedido-numero">
                <h2>Número de Pedido</h2>
                <p className="numero">{pedido.numeroPedido || `#${pedido.id}`}</p>
              </div>

              <div className="pedido-info-grid">
                <div className="info-card">
                  <div className="info-icon">📅</div>
                  <div className="info-content">
                    <h3>Fecha del Pedido</h3>
                    <p>{formatDate(pedido.fechaPedido || pedido.fechaCreacion)}</p>
                  </div>
                </div>

                <div className="info-card">
                  <div className="info-icon">💰</div>
                  <div className="info-content">
                    <h3>Total Pagado</h3>
                    <p className="total-amount">{formatPrice(pedido.total)}</p>
                  </div>
                </div>

                <div className="info-card">
                  <div className="info-icon">💳</div>
                  <div className="info-content">
                    <h3>Método de Pago</h3>
                    <p className="metodo-usado">
                      {pedido.metodoPago === 'tarjeta' && 'Tarjeta de Crédito/Débito'}
                      {pedido.metodoPago === 'paypal' && 'PayPal'}
                      {pedido.metodoPago === 'webpay' && 'Webpay Plus'}
                      {!pedido.metodoPago && 'Pendiente'}
                    </p>
                  </div>
                </div>

                <div className="info-card">
                  <div className="info-icon">📦</div>
                  <div className="info-content">
                    <h3>Estado</h3>
                    <p className="estado-badge">
                      {pedido.estadoPedido || 'En proceso'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="pedido-detalles">
                <h2>Detalles del Pedido</h2>
                
                <div className="items-list">
                  {(pedido.items || []).map((item, index) => (
                    <div key={index} className="item-detalle">
                      <span className="item-nombre">
                        {item.nombreProducto || item.producto?.nombre}
                      </span>
                      <span className="item-cantidad">x{item.cantidad}</span>
                      <span className="item-precio">{formatPrice(item.subtotal)}</span>
                    </div>
                  ))}
                </div>

                <div className="totales-resumen">
                  <div className="total-linea">
                    <span>Subtotal:</span>
                    <span>{formatPrice(pedido.subtotal)}</span>
                  </div>
                  <div className="total-linea">
                    <span>Envío:</span>
                    <span>{formatPrice(pedido.envio || 5000)}</span>
                  </div>
                  <div className="total-linea total-final">
                    <span>Total:</span>
                    <span>{formatPrice(pedido.total)}</span>
                  </div>
                </div>
              </div>

              <div className="direccion-envio-card">
                <h3>📍 Dirección de Envío</h3>
                <p>{pedido.direccionEnvio}</p>
                <p>📞 {pedido.telefonoContacto}</p>
              </div>
            </>
          )}

          <div className="siguientes-pasos">
            <h3>¿Qué sigue?</h3>
            <div className="pasos-grid">
              <div className="paso">
                <div className="paso-numero">1</div>
                <p><strong>Confirmación del Administrador</strong></p>
                <small>El administrador revisará y confirmará tu pedido</small>
              </div>
              <div className="paso">
                <div className="paso-numero">2</div>
                <p><strong>Preparación</strong></p>
                <small>Tu pedido será preparado cuidadosamente</small>
              </div>
              <div className="paso">
                <div className="paso-numero">3</div>
                <p><strong>Envío</strong></p>
                <small>Recibirás tu pedido en la dirección indicada</small>
              </div>
            </div>
          </div>

          <div className="acciones">
            <Link to="/pedidos" className="btn-primary">
              Ver Mis Pedidos
            </Link>
            <Link to="/catalogo" className="btn-secondary">
              Seguir Comprando
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default PedidoExitoso;
