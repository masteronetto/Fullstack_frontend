import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import './Blogs.css';

const Blogs = () => {
  const navigate = useNavigate();

  const blogs = [
    {
      id: 1,
      titulo: "¡Descubre los Nuevos Productos de Nuestra Tienda!",
      descripcion: "Explora nuestra colección actualizada de productos personalizados. Desde poleras y polerón hasta agendas, stickers y tarjetas de presentación. ¡Cada pieza es única y hecha especialmente para ti!",
      imagen: "/src/assets/Poleron3.avif",
      botonTexto: "Ver Catálogo",
      botonAccion: () => navigate('/catalogo'),
      destacado: true
    },
    {
      id: 2,
      titulo: "Personaliza Tu Estilo con Kebumy",
      descripcion: "¿Buscas un regalo especial o quieres destacar tu marca personal? En Kebumy transformamos tus ideas en productos únicos. Diseños exclusivos para ocasiones especiales que te harán brillar.",
      imagen: "/src/assets/polaroid2.avif",
      botonTexto: "Conocer Más",
      botonAccion: () => navigate('/contacto'),
      destacado: false
    },
    {
      id: 3,
      titulo: "Kebumy Para Empresas",
      descripcion: "Impulsa tu marca con nuestros productos corporativos personalizados. Tarjetas de presentación, merchandising y regalos empresariales que dejarán huella. Consulta por pedidos al por mayor con descuentos especiales.",
      imagen: "/src/assets/imagen producto 1.webp",
      botonTexto: "Cotizar Ahora",
      botonAccion: () => navigate('/contacto'),
      destacado: false
    }
  ];

  return (
    <div className="blogs-page">
      <Navbar />
      
      <main className="blogs-main">
        <div className="blogs-container">
          <h1 className="blogs-title">Noticias Importantes</h1>
          <p className="blogs-subtitle">
            Mantente informado sobre nuestros nuevos productos, promociones y novedades
          </p>

          <div className="blogs-grid">
            {blogs.map((blog) => (
              <article 
                key={blog.id} 
                className={`blog-card ${blog.destacado ? 'blog-destacado' : ''}`}
              >
                <div className="blog-image-container">
                  <img 
                    src={blog.imagen} 
                    alt={blog.titulo}
                    className="blog-image"
                  />
                  {blog.destacado && (
                    <div className="blog-badge">
                      ⭐ Destacado
                    </div>
                  )}
                </div>

                <div className="blog-content">
                  <h2 className="blog-titulo">{blog.titulo}</h2>
                  <p className="blog-descripcion">{blog.descripcion}</p>
                  
                  <button 
                    className="blog-boton"
                    onClick={blog.botonAccion}
                  >
                    {blog.botonTexto}
                  </button>
                </div>
              </article>
            ))}
          </div>

          {/* Sección de llamado a la acción */}
          <div className="blogs-cta">
            <h2>¿Tienes alguna pregunta?</h2>
            <p>Nuestro equipo está listo para ayudarte con tus proyectos personalizados</p>
            <button 
              className="cta-button"
              onClick={() => navigate('/contacto')}
            >
              Contáctanos
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Blogs;
