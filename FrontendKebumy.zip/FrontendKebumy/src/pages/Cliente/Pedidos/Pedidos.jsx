import React, { useState, useEffect } from 'react';
// Datos fijos de la empresa para la boleta
const EMPRESA = {
  nombre: 'Kebumy SpA',
  rut: '76.123.456-7',
  direccion: 'Av. Principal 1234, Santiago, Chile',
  giro: 'Comercio al por menor de prendas y accesorios',
  telefono: '+56 9 1234 5678',
  email: 'contacto@kebumy.cl'
};
import { Link } from 'react-router-dom';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import useClientAuth from '../../../hooks/cliente/useClientAuth';
import useAuth from '../../../hooks/useAuth';
import apiService from '../../../services/apiService';
import './Pedidos.css';

const Pedidos = () => {
    // Estado para el modal de boleta
    const [boletaOpen, setBoletaOpen] = useState(false);
    const [pedidoBoleta, setPedidoBoleta] = useState(null);
    // Función para abrir el modal de boleta
    const handleOpenBoleta = (pedido) => {
      setPedidoBoleta(pedido);
      setBoletaOpen(true);
    };

    // Función para cerrar el modal
    const handleCloseBoleta = () => {
      setBoletaOpen(false);
      setPedidoBoleta(null);
    };
  const clientAuth = useClientAuth();
  const generalAuth = useAuth();
  
  // Detectar usuario de cualquiera de los dos sistemas de autenticación
  const user = clientAuth.user || generalAuth.user;
  const isAuthenticated = clientAuth.isAuthenticated || generalAuth.isAuthenticated;
  
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    cargarPedidos();
  }, [user]);

  const handleRecargar = () => {
    cargarPedidos();
  };

  const cargarPedidos = async () => {
    if (!user || !user.id) {
      console.log('⚠️ No hay usuario logueado');
      setLoading(false);
      setPedidos([]);
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      console.log('📋 Cargando pedidos del usuario:', user.id);
      console.log('👤 Usuario completo:', user);
      const response = await apiService.getPedidosCliente(user.id);
      
      console.log('📦 Respuesta RAW del backend:', response);
      console.log('📦 Tipo de respuesta:', typeof response, Array.isArray(response));
      
      // La respuesta puede venir como { pedidos: [...] } o directamente como [...]
      const pedidosData = response.pedidos || response;
      
      console.log('✅ Pedidos extraídos:', pedidosData);
      console.log('📊 Total de pedidos:', pedidosData?.length || 0);
      setPedidos(Array.isArray(pedidosData) ? pedidosData : []);
    } catch (error) {
      console.error('❌ Error al cargar pedidos:', error);
      setError('No se pudieron cargar tus pedidos');
      setPedidos([]);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(price);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Fecha no disponible';
    return new Date(dateString).toLocaleDateString('es-CL', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getEstadoBadge = (estado) => {
    const estados = {
      'pendiente': { color: '#ffc107', label: 'Pendiente' },
      'pagado': { color: '#17a2b8', label: 'Pagado' },
      'aprobado': { color: '#28a745', label: 'Aprobado' },
      'rechazado': { color: '#dc3545', label: 'Rechazado' },
      'preparando': { color: '#007bff', label: 'Preparando' },
      'enviado': { color: '#6f42c1', label: 'Enviado' },
      'entregado': { color: '#20c997', label: 'Entregado' },
      'cancelado': { color: '#6c757d', label: 'Cancelado' }
    };
    
    const estadoInfo = estados[estado?.toLowerCase()] || { color: '#6c757d', label: estado || 'Desconocido' };
    return (
      <span 
        className="estado-badge" 
        style={{ backgroundColor: estadoInfo.color }}
      >
        {estadoInfo.label}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="pedidos-page">
        <Navbar />
        <div className="pedidos-container">
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Cargando tus pedidos...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="pedidos-page">
      <Navbar />
      
      <div className="pedidos-container">
        <div className="pedidos-header">
          <div>
            <h1>Mis Pedidos</h1>
            <p>Historial de compras y estado de envíos</p>
          </div>
          <button onClick={handleRecargar} className="btn-recargar" disabled={loading}>
            {loading ? '🔄 Cargando...' : '🔄 Actualizar'}
          </button>
        </div>

        {error && (
          <div className="error-message">
            <p>⚠️ {error}</p>
            <button onClick={cargarPedidos} className="btn-retry">Reintentar</button>
          </div>
        )}

        {pedidos.length === 0 ? (
          <div className="pedidos-empty">
            <div className="empty-icon">📦</div>
            <h2>No hay pedidos realizados</h2>
            <p>Aún no has realizado ninguna compra. ¡Explora nuestro catálogo y haz tu primer pedido!</p>
            <Link to="/catalogo" className="btn-primary">Explorar Tienda</Link>
          </div>
        ) : (
          <div className="pedidos-list">
            {pedidos.map((pedido) => (
              <div key={pedido.id} className="pedido-card">
                <div className="pedido-header-row">
                  <div className="pedido-info">
                    <h3>Pedido #{pedido.numeroPedido || pedido.id}</h3>
                    <p className="pedido-fecha">{formatDate(pedido.fechaPedido || pedido.fecha)}</p>
                  </div>
                  <div className="pedido-meta">
                    {getEstadoBadge(pedido.estadoPedido || pedido.estado)}
                    <span className="pedido-total">{formatPrice(pedido.total)}</span>
                  </div>
                </div>

                <div className="pedido-productos">
                  {(pedido.items || pedido.productos || []).map((item, index) => {
                    // Construir URL de imagen
                    let imagenUrl = item.producto?.imagenUrl || item.imagen_url || item.imagen;
                    if (imagenUrl && !imagenUrl.startsWith('http') && !imagenUrl.startsWith('/src')) {
                      imagenUrl = `http://localhost:3000/${imagenUrl}`;
                    }
                    
                    return (
                      <div key={index} className="producto-mini">
                        <img 
                          src={imagenUrl || '/src/assets/placeholder-product.png'} 
                          alt={item.producto?.nombre || item.nombre}
                        />
                        <div className="producto-mini-info">
                          <span className="nombre">{item.producto?.nombre || item.nombre}</span>
                          <span className="cantidad">×{item.cantidad}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>


                <div className="pedido-resumen">
                  <div className="resumen-item">
                    <span>Subtotal:</span>
                    <span>{formatPrice(pedido.subtotal || pedido.total - (pedido.envio || 0) - (pedido.iva || 0))}</span>
                  </div>
                  <div className="resumen-item">
                    <span>IVA:</span>
                    <span>{pedido.iva !== undefined ? formatPrice(pedido.iva) : 'No informado'}</span>
                  </div>
                  <div className="resumen-item">
                    <span>Envío:</span>
                    <span>{pedido.envio !== undefined ? formatPrice(pedido.envio) : 'No informado'}</span>
                  </div>
                  <div className="resumen-item resumen-total">
                    <span>Total:</span>
                    <span>{formatPrice(pedido.total)}</span>
                  </div>
                  {pedido.estadoPago && (
                    <div className="resumen-item">
                      <span>Estado Pago:</span>
                      <span className={`estado-pago ${pedido.estadoPago}`}>{pedido.estadoPago}</span>
                    </div>
                  )}
                </div>

                <div className="pedido-actions">
                  <Link to={`/pedidos/${pedido.id}`} className="btn-ver-detalle">
                    Ver Detalles
                  </Link>
                  <button className="btn-boleta" onClick={() => handleOpenBoleta(pedido)}>
                    Boleta
                  </button>
                </div>
                    {/* Modal de Boleta */}
                    {boletaOpen && pedidoBoleta && (
                      <div className="modal-boleta-overlay" onClick={handleCloseBoleta}>
                        <div className="modal-boleta" onClick={e => e.stopPropagation()}>
                          <button className="modal-boleta-close" onClick={handleCloseBoleta}>×</button>
                          <h2>Boleta Electrónica</h2>
                          <div className="boleta-empresa">
                            <strong>{EMPRESA.nombre}</strong><br/>
                            RUT: {EMPRESA.rut}<br/>
                            {EMPRESA.direccion}<br/>
                            Giro: {EMPRESA.giro}<br/>
                            Fono: {EMPRESA.telefono}<br/>
                            Email: {EMPRESA.email}
                          </div>
                          <hr/>
                          <div className="boleta-cliente">
                            <strong>Cliente:</strong> {user?.nombre || user?.email || 'No disponible'}<br/>
                            Email: {user?.email}<br/>
                            Fecha: {formatDate(pedidoBoleta.fechaPedido || pedidoBoleta.fecha)}
                          </div>
                          <hr/>
                          <div className="boleta-detalle">
                            <strong>Detalle de la compra:</strong>
                            <ul>
                              {(pedidoBoleta.items || pedidoBoleta.productos || []).map((item, idx) => (
                                <li key={idx}>
                                  {item.producto?.nombre || item.nombre} ×{item.cantidad} - {formatPrice(item.precio)}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <hr/>
                          <div className="boleta-totales">
                            <div>Subtotal: {formatPrice(pedidoBoleta.subtotal || pedidoBoleta.total - (pedidoBoleta.envio || 0) - (pedidoBoleta.iva || 0))}</div>
                            <div>IVA: {pedidoBoleta.iva !== undefined ? formatPrice(pedidoBoleta.iva) : 'No informado'}</div>
                            <div>Envío: {pedidoBoleta.envio !== undefined ? formatPrice(pedidoBoleta.envio) : 'No informado'}</div>
                            <div><strong>Total: {formatPrice(pedidoBoleta.total)}</strong></div>
                          </div>
                          <div className="boleta-id">N° Boleta: {pedidoBoleta.numeroPedido || pedidoBoleta.id}</div>
                        </div>
                      </div>
                    )}
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default Pedidos;
