import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import apiService from '../../../services/apiService';
import './PagoExitoso.css';

const PagoExitoso = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [pedido, setPedido] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const confirmarPago = async () => {
      const sessionId = searchParams.get('session_id');

      if (!sessionId) {
        setError('No se encontró información del pago');
        setLoading(false);
        return;
      }

      try {
        // Confirmar pago en el backend
        const response = await apiService.confirmarPago(sessionId);

        if (response.success) {
          setPedido(response.pedido);
        } else {
          throw new Error('No se pudo confirmar el pago');
        }
      } catch (err) {
        console.error('Error confirmando pago:', err);
        setError(err.message || 'Error al confirmar el pago');
      } finally {
        setLoading(false);
      }
    };

    confirmarPago();
  }, [searchParams]);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(price);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="pago-exitoso-page">
        <Navbar />
        <div className="loading-container">
          <div className="spinner"></div>
          <p>Confirmando tu pago...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="pago-exitoso-page">
        <Navbar />
        <div className="error-container">
          <div className="error-icon">❌</div>
          <h2>Error al Confirmar Pago</h2>
          <p>{error}</p>
          <button onClick={() => navigate('/carrito')} className="btn-volver">
            Volver al Carrito
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="pago-exitoso-page">
      <Navbar />

      <div className="pago-exitoso-container">
        <div className="success-card">
          <div className="success-icon">✅</div>
          
          <h1>¡Pago Exitoso!</h1>
          <p className="success-message">
            Tu pedido ha sido confirmado y está siendo procesado
          </p>

          {pedido && (
            <div className="pedido-details">
              <div className="detail-row">
                <span className="label">Número de Pedido:</span>
                <span className="value"><strong>{pedido.numeroPedido}</strong></span>
              </div>

              <div className="detail-row">
                <span className="label">Fecha:</span>
                <span className="value">{formatDate(pedido.fechaPedido)}</span>
              </div>

              <div className="detail-row">
                <span className="label">Subtotal:</span>
                <span className="value">{formatPrice(pedido.subtotal)}</span>
              </div>
              <div className="detail-row">
                <span className="label">IVA (19%):</span>
                <span className="value">{formatPrice(pedido.iva !== undefined ? pedido.iva : Math.round((pedido.subtotal || 0) * 0.19))}</span>
              </div>

              {/* Cálculo robusto de IVA para el total */}
              {(() => {
                // Si el backend no envía IVA, lo calculamos aquí para el total
                if (pedido.iva === undefined) {
                  pedido.iva = Math.round((pedido.subtotal || 0) * 0.19);
                }
                return null;
              })()}
              <div className="detail-row">
                <span className="label">Envío:</span>
                <span className="value">{pedido.envio !== undefined ? formatPrice(pedido.envio) : 'No informado'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Total Pagado:</span>
                <span className="value total-amount">{formatPrice((pedido.subtotal || 0) + (pedido.iva !== undefined ? pedido.iva : Math.round((pedido.subtotal || 0) * 0.19)) + (pedido.envio !== undefined ? pedido.envio : 5000))}</span>
              </div>

              <div className="detail-row">
                <span className="label">Estado:</span>
                <span className="value estado-badge">{pedido.estadoPedido}</span>
              </div>

              <div className="detail-row full-width">
                <span className="label">Dirección de Envío:</span>
                <span className="value">
                  {pedido.direccionEnvio}<br />
                  {pedido.ciudad}, {pedido.region}<br />
                  {pedido.codigoPostal && `CP: ${pedido.codigoPostal}`}
                </span>
              </div>

              {pedido.items && pedido.items.length > 0 && (
                <div className="productos-pedido">
                  <h3>Productos del Pedido</h3>
                  {pedido.items.map((item, index) => (
                    <div key={index} className="producto-item">
                      <div className="producto-info">
                        <span className="producto-nombre">{item.nombreProducto}</span>
                        <span className="producto-cantidad">x{item.cantidad}</span>
                      </div>
                      <span className="producto-precio">
                        {formatPrice(item.subtotal)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="next-steps">
            <h3>¿Qué sigue?</h3>
            <ul>
              <li>📧 Te enviaremos un email de confirmación</li>
              <li>📦 Prepararemos tu pedido en 1-2 días hábiles</li>
              <li>🚚 Recibirás información de seguimiento de envío</li>
            </ul>
          </div>

          <div className="actions">
            <button 
              onClick={() => navigate('/pedidos')} 
              className="btn-primary"
            >
              Ver Mis Pedidos
            </button>
            <button 
              onClick={() => navigate('/catalogo')} 
              className="btn-secondary"
            >
              Seguir Comprando
            </button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default PagoExitoso;
