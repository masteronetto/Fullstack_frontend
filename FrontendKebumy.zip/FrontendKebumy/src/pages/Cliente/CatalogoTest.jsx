import React from 'react';

const CatalogoTest = () => {
  console.log('🛍️ Catalogo Test component rendering...');
  
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>🛍️ Catálogo de Productos - TEST</h1>
      <p>Componente Catalogo funcionando correctamente!</p>
      <div style={{ marginTop: '20px' }}>
        <a href="/" style={{ margin: '0 10px', color: '#007bff' }}>Volver al Inicio</a>
        <a href="/carrito" style={{ margin: '0 10px', color: '#007bff' }}>Carrito</a>
        <a href="/mi-cuenta" style={{ margin: '0 10px', color: '#007bff' }}>Mi Cuenta</a>
        <a href="/pedidos" style={{ margin: '0 10px', color: '#007bff' }}>Pedidos</a>
      </div>
    </div>
  );
};

export default CatalogoTest;