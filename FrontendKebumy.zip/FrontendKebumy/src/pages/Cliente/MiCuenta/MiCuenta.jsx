import React, { useState, useEffect } from 'react';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import useAuth from '../../../hooks/useAuth';
import apiService from '../../../services/apiService';
import './MiCuenta.css';

const MiCuenta = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('perfil');
  const [perfilData, setPerfilData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    direccion: '',
    fechaNacimiento: ''
  });
  const [editMode, setEditMode] = useState(false);
  const [pedidosRecientes, setPedidosRecientes] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Cargar datos del usuario autenticado
    if (user) {
      setPerfilData({
        nombre: user.nombre || 'Usuario',
        email: user.email || 'usuario@ejemplo.com',
        telefono: user.telefono || '+56 9 8765 4321',
        direccion: user.direccion || 'Av. Principal 123, Santiago, Chile',
        fechaNacimiento: user.fechaNacimiento || '1990-01-01'
      });
      cargarPedidosRecientes();
    }
  }, [user]);

  const cargarPedidosRecientes = async () => {
    if (!user?.id) return;

    setLoading(true);
    try {
      const pedidos = await apiService.getPedidosCliente(user.id);
      // Tomar solo los 3 pedidos más recientes
      setPedidosRecientes(pedidos.slice(0, 3));
    } catch (error) {
      console.error('❌ Error al cargar pedidos del backend:', error);
      setPedidosRecientes([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    setLoading(true);
    try {
      // Actualizar perfil usando la API del backend
      if (user?.id) {
        await apiService.actualizarPerfil(user.id, perfilData);
        
        // Actualizar datos locales del usuario
        const updatedUser = { ...user, ...perfilData };
        localStorage.setItem('kebumy_user', JSON.stringify(updatedUser));
      }
      
      setEditMode(false);
      console.log('✅ Perfil actualizado exitosamente en el backend');
    } catch (error) {
      console.error('Error al actualizar perfil:', error);
      alert('Error al actualizar el perfil. Inténtalo nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  const handlePerfilSubmit = (e) => {
    e.preventDefault();
    handleSaveProfile();
  };

  const getEstadoClass = (estado) => {
    switch(estado) {
      case 'Entregado': return 'estado-entregado';
      case 'En tránsito': return 'estado-transito';
      case 'Procesando': return 'estado-procesando';
      case 'Cancelado': return 'estado-cancelado';
      default: return '';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('es-CL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <>
      <Navbar />
      <div className="mi-cuenta-page">
        <div className="mi-cuenta-container">
        <div className="cuenta-header">
          <h1>Mi Cuenta</h1>
          <p>Gestiona tu información personal y revisa tus pedidos</p>
        </div>

        <div className="cuenta-content">
          <div className="cuenta-sidebar">
            <nav className="cuenta-nav">
              <button
                className={`nav-item ${activeTab === 'perfil' ? 'active' : ''}`}
                onClick={() => setActiveTab('perfil')}
              >
                <span className="nav-icon">👤</span>
                Mi Perfil
              </button>
              <button
                className={`nav-item ${activeTab === 'pedidos' ? 'active' : ''}`}
                onClick={() => setActiveTab('pedidos')}
              >
                <span className="nav-icon">📦</span>
                Mis Pedidos
              </button>
            </nav>
          </div>

          <div className="cuenta-main">
            {activeTab === 'perfil' && (
              <div className="tab-content">
                <div className="content-header">
                  <h2>Información Personal</h2>
                  <button 
                    className="btn-edit"
                    onClick={() => setEditMode(!editMode)}
                  >
                    {editMode ? 'Cancelar' : 'Editar'}
                  </button>
                </div>

                <form onSubmit={handlePerfilSubmit} className="perfil-form">
                  <div className="form-grid">
                    <div className="form-group">
                      <label htmlFor="nombre">Nombre Completo</label>
                      <input
                        type="text"
                        id="nombre"
                        value={perfilData.nombre}
                        onChange={(e) => setPerfilData({...perfilData, nombre: e.target.value})}
                        disabled={!editMode}
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="email">Email</label>
                      <input
                        type="email"
                        id="email"
                        value={perfilData.email}
                        onChange={(e) => setPerfilData({...perfilData, email: e.target.value})}
                        disabled={!editMode}
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="telefono">Teléfono</label>
                      <input
                        type="tel"
                        id="telefono"
                        value={perfilData.telefono}
                        onChange={(e) => setPerfilData({...perfilData, telefono: e.target.value})}
                        disabled={!editMode}
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="fechaNacimiento">Fecha de Nacimiento</label>
                      <input
                        type="date"
                        id="fechaNacimiento"
                        value={perfilData.fechaNacimiento}
                        onChange={(e) => setPerfilData({...perfilData, fechaNacimiento: e.target.value})}
                        disabled={!editMode}
                      />
                    </div>

                    <div className="form-group full-width">
                      <label htmlFor="direccion">Dirección</label>
                      <input
                        type="text"
                        id="direccion"
                        value={perfilData.direccion}
                        onChange={(e) => setPerfilData({...perfilData, direccion: e.target.value})}
                        disabled={!editMode}
                      />
                    </div>
                  </div>

                  {editMode && (
                    <div className="form-actions">
                      <button 
                        type="submit" 
                        className="btn-save"
                        disabled={loading}
                      >
                        {loading ? 'Guardando...' : 'Guardar Cambios'}
                      </button>
                    </div>
                  )}
                </form>
              </div>
            )}

            {activeTab === 'pedidos' && (
              <div className="tab-content">
                <div className="content-header">
                  <h2>Historial de Pedidos</h2>
                  <span className="pedidos-count">
                    {pedidosRecientes.length} pedidos recientes
                  </span>
                </div>

                {loading ? (
                  <div className="loading-state">
                    <div className="loading-spinner"></div>
                    <p>Cargando pedidos...</p>
                  </div>
                ) : pedidosRecientes.length > 0 ? (
                  <div className="pedidos-list">
                    {pedidosRecientes.map((pedido) => (
                    <div key={pedido.id} className="pedido-card">
                      <div className="pedido-header">
                        <div className="pedido-info">
                          <h3>Pedido {pedido.id}</h3>
                          <p className="pedido-fecha">{formatDate(pedido.fecha)}</p>
                        </div>
                        <div className="pedido-meta">
                          <span className={`pedido-estado ${getEstadoClass(pedido.estado)}`}>
                            {pedido.estado}
                          </span>
                          <span className="pedido-total">{formatCurrency(pedido.total)}</span>
                        </div>
                      </div>

                      <div className="pedido-details">
                        <div className="detail-item">
                          <span className="detail-label">Productos:</span>
                          <span>{pedido.productos} artículo{pedido.productos > 1 ? 's' : ''}</span>
                        </div>
                        {pedido.tracking && (
                          <div className="detail-item">
                            <span className="detail-label">Seguimiento:</span>
                            <span className="tracking-code">{pedido.tracking}</span>
                          </div>
                        )}
                      </div>

                      <div className="pedido-actions">
                        <button className="btn-ver-detalle">Ver Detalle</button>
                        {pedido.tracking && (
                          <button className="btn-seguimiento">Seguir Envío</button>
                        )}
                        {pedido.estado === 'Entregado' && (
                          <button className="btn-recomprar">Volver a Comprar</button>
                        )}
                      </div>
                    </div>
                  ))}
                  </div>
                ) : (
                  <div className="no-pedidos">
                    <div className="no-pedidos-icon">📦</div>
                    <h3>No tienes pedidos aún</h3>
                    <p>¡Explora nuestro catálogo y realiza tu primera compra!</p>
                    <a href="/catalogo" className="btn-explorar">Explorar Productos</a>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
    <Footer />
    </>
  );
};

export default MiCuenta;