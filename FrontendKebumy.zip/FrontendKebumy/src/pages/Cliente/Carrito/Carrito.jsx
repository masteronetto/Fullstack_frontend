import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import useCart from '../../../hooks/cliente/useCart';
import useClientAuth from '../../../hooks/cliente/useClientAuth';
import useAuth from '../../../hooks/useAuth';
import apiService from '../../../services/apiService';
import './Carrito.css';

const Carrito = () => {
    const handleClearCart = () => {
      if (window.confirm('¿Estás seguro de que quieres vaciar el carrito?')) {
        clearCart();
      }
    };
  const { 
    cartItems, 
    updateQuantity, 
    removeFromCart, 
    clearCart,
    getTotalPrice,
    getTotalItems
  } = useCart();
  
  const navigate = useNavigate();
  const clientAuth = useClientAuth();
  const generalAuth = useAuth();
  
  // Detectar usuario de cualquier sistema de autenticación
  const user = clientAuth.user || generalAuth.user;
  const isAuthenticated = clientAuth.isAuthenticated || generalAuth.isAuthenticated;
  
  const [loading, setLoading] = useState(false);
  const [pedidoCreado, setPedidoCreado] = useState(null);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(price);
  };

  const handleQuantityChange = (productId, newQuantity) => {
    if (newQuantity < 1) return;
    updateQuantity(productId, parseInt(newQuantity));
  };

  const handleProcederPago = async () => {
    if (cartItems.length === 0) {
      alert('Tu carrito está vacío');
      return;
    }

    if (!user || !isAuthenticated) {
      alert('Debes iniciar sesión para proceder con el pago');
      navigate('/login');
      return;
    }

    console.log('🛒 Procesando pago para usuario:', user);
    console.log('🛒 Items en carrito local:', cartItems);

    setLoading(true);
    try {
      // Formatear items del carrito
      const itemsParaBackend = cartItems.map(item => ({
        productoId: item.id,
        cantidad: item.cantidad,
        precio: item.precio
      }));
      
      console.log('📦 Items para enviar:', itemsParaBackend);

      // Datos de envío básicos
      const iva = Math.round(getTotalPrice() * 0.19);
      const datosEnvio = {
        direccion: "Dirección de ejemplo", // TODO: Capturar del formulario
        ciudad: "Santiago",
        region: "Metropolitana",
        codigoPostal: "12345",
        telefono: user.telefono || "Sin teléfono",
        notas: "",
        iva
      };

      // Intentar sincronizar carrito primero (si falla, continuamos)
      try {
        console.log('🔄 Sincronizando carrito con backend...');
        await apiService.sincronizarCarrito(user.id, itemsParaBackend);
        console.log('✅ Carrito sincronizado');
      } catch (syncError) {
        console.warn('⚠️ No se pudo sincronizar carrito, continuando con pedido:', syncError.message);
        // Continuamos aunque falle la sincronización
      }

      // Crear pedido (SIN Stripe, versión simulada)
      console.log('💳 Creando pedido...');
      const response = await apiService.crearPedido(user.id, datosEnvio);
      
      if (response.success && response.checkoutUrl) {
        // Limpiar carrito local
        clearCart();
        
        // Redirigir a página de checkout simulada
        navigate(response.checkoutUrl);
      } else {
        throw new Error('No se pudo crear el pedido');
      }
      
    } catch (error) {
      console.error('Error al procesar el pago:', error);
      alert('Error al procesar el pago: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  // Si se creó un pedido exitosamente, mostrar confirmación
  if (pedidoCreado) {
    return (
      <div className="carrito-page">
        <Navbar />
        <div className="carrito-container">
          <div className="pedido-confirmacion">
            <div className="confirmacion-content">
              <div className="confirmacion-icon">✅</div>
              <h2>¡Pedido creado exitosamente!</h2>
              <p><strong>Número de pedido:</strong> {pedidoCreado.id}</p>
              <p><strong>Total:</strong> {formatPrice(pedidoCreado.total)}</p>
              <p>Te enviaremos un email con los detalles del pedido.</p>
              <div className="confirmacion-actions">
                <Link to="/pedidos" className="btn-ver-pedidos">Ver mis pedidos</Link>
                <Link to="/catalogo" className="btn-continue-shopping">Seguir comprando</Link>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Render principal del carrito
  const totalItems = getTotalItems();
  const totalPrice = getTotalPrice();
  const iva = Math.round(totalPrice * 0.19);
  const shipping = totalPrice > 50000 ? 0 : 5000;
  const finalTotal = totalPrice + iva + shipping;

  if (cartItems.length === 0) {
    return (
      <div className="carrito-page">
        <Navbar />
        <div className="carrito-container" style={{ display: 'flex', alignItems: 'flex-start' }}>
          <aside
            className="carrito-menu"
            style={{
              width: 320,
              marginRight: 32,
              background: 'linear-gradient(135deg, #f7e6fa 0%, #f7f3ed 100%)',
              borderRadius: 18,
              padding: 28,
              minHeight: 400,
              boxShadow: '0 4px 24px 0 rgba(176,65,122,0.10)',
              border: '1.5px solid #e8e2d8',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'stretch',
            }}
          >
            <h3>Carrito</h3>
            <div style={{ color: '#b0417a', fontWeight: 600, marginTop: 24 }}>Tu carrito está vacío</div>
          </aside>
          <div className="summary-card">
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatPrice(totalPrice)}</span>
            </div>
            <div className="summary-row">
              <span>IVA (19%)</span>
              <span>{formatPrice(iva)}</span>
            </div>
            <div className="summary-row">
              <span>Envío</span>
              <span>{formatPrice(shipping)}</span>
            </div>
            {shipping > 0 && (
              <div className="shipping-note">
                <small>💡 Envío gratis en compras sobre {formatPrice(50000)}</small>
              </div>
            )}
            <div className="summary-divider"></div>
            <div className="summary-total">
              <span>Total</span>
              <span>{formatPrice(finalTotal)}</span>
            </div>
            <div className="checkout-actions">
              <Link to="/catalogo" className="btn-continue-shopping">Seguir Comprando</Link>
              <button className="btn-cancel-checkout" onClick={() => navigate('/tienda')} style={{background:'#e8e2d8',color:'#b0417a',border:'1.5px solid #b0417a',marginRight:8}}>Cancelar Compra</button>
              <button className="btn-checkout" onClick={handleProcederPago} disabled={loading}>{loading ? 'Procesando...' : 'Finalizar Compra'}</button>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <>
      <div className="carrito-page">
        <Navbar />
        <div className="carrito-container" style={{ display: 'flex', alignItems: 'flex-start' }}>
          <aside
            className="carrito-menu"
            style={{
              width: 340,
              marginRight: 32,
              background: 'linear-gradient(135deg, #f7e6fa 0%, #f7f3ed 100%)',
              borderRadius: 18,
              padding: 28,
              minHeight: 400,
              boxShadow: '0 4px 24px 0 rgba(176,65,122,0.10)',
              border: '1.5px solid #e8e2d8',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'stretch',
            }}
          >
            <h2 style={{ fontWeight: 800, color: '#7a2c6b', marginBottom: 18, letterSpacing: 1 }}>CARRITO</h2>
            {cartItems.length > 0 ? (
              <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                {cartItems.map((item) => {
                  let imagenUrl = item.imagen_url || item.imagenUrl;
                  if (imagenUrl && !imagenUrl.startsWith('http') && !imagenUrl.startsWith('/src/assets')) {
                    imagenUrl = `http://localhost:3000/${imagenUrl}`;
                  } else if (!imagenUrl) {
                    imagenUrl = '/src/assets/placeholder-product.png';
                  }
                  return (
                    <li key={item.id} style={{
                      marginBottom: 22,
                      borderBottom: '1px solid #e8e2d8',
                      paddingBottom: 16,
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 12
                    }}>
                      <img
                        src={imagenUrl}
                        alt={item.nombre}
                        style={{
                          width: 60,
                          height: 60,
                          objectFit: 'cover',
                          borderRadius: 12,
                          boxShadow: '0 2px 8px 0 rgba(176,65,122,0.08)',
                          background: '#fff',
                          border: '1px solid #e8e2d8',
                        }}
                        onError={e => { e.target.onerror = null; e.target.src = '/src/assets/placeholder-product.png'; }}
                      />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: 16, color: '#7a2c6b', marginBottom: 2 }}>{item.nombre}</div>
                        <div style={{ fontSize: 13, color: '#b0417a', marginBottom: 4 }}>{formatPrice(item.precio)}</div>
                        <div style={{ fontSize: 13, color: '#7a2c6b', marginBottom: 4 }}>{item.categoria_nombre || item.categoria}</div>
                        <div style={{ fontSize: 12, color: '#6d6d6d', marginBottom: 6, minHeight: 16 }}>
                          {item.descripcion && item.descripcion.length > 50
                            ? `${item.descripcion.substring(0, 50)}...`
                            : item.descripcion}
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <button
                            style={{
                              width: 26,
                              height: 26,
                              borderRadius: 6,
                              border: '1px solid #b0417a',
                              background: '#fff',
                              color: '#b0417a',
                              fontWeight: 700,
                              fontSize: 16,
                              cursor: 'pointer',
                              lineHeight: 1
                            }}
                            onClick={() => handleQuantityChange(item.id, item.cantidad - 1)}
                            disabled={item.cantidad <= 1}
                          >-</button>
                          <input
                            type="number"
                            min="1"
                            max="99"
                            value={item.cantidad}
                            onChange={e => handleQuantityChange(item.id, Number(e.target.value))}
                            style={{
                              width: 36,
                              textAlign: 'center',
                              border: '1px solid #e8e2d8',
                              borderRadius: 6,
                              fontWeight: 600,
                              color: '#7a2c6b',
                              background: '#f7f3ed',
                              margin: '0 2px'
                            }}
                          />
                          <button
                            style={{
                              width: 26,
                              height: 26,
                              borderRadius: 6,
                              border: '1px solid #b0417a',
                              background: '#fff',
                              color: '#b0417a',
                              fontWeight: 700,
                              fontSize: 16,
                              cursor: 'pointer',
                              lineHeight: 1
                            }}
                            onClick={() => handleQuantityChange(item.id, item.cantidad + 1)}
                          >+</button>
                          <button
                            className="btn-remove"
                            onClick={() => removeFromCart(item.id)}
                            title="Eliminar producto"
                            style={{
                              marginLeft: 8,
                              background: 'none',
                              border: 'none',
                              color: '#b0417a',
                              fontSize: 18,
                              cursor: 'pointer',
                            }}
                          >🗑️</button>
                        </div>
                        <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>
                          Total: <b>{formatPrice(item.precio * item.cantidad)}</b>
                        </div>
                        {item.stock && (
                          <div style={{ fontSize: 11, color: '#b0417a', marginTop: 2 }}>Stock: {item.stock}</div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <div style={{ color: '#b0417a', fontWeight: 600, marginTop: 24, textAlign: 'center', fontSize: 18 }}>Tu carrito está vacío</div>
            )}
            {cartItems.length > 0 && (
              <button className="btn-clear-cart" onClick={handleClearCart} style={{ marginTop: 24, background: '#fff', color: '#b0417a', border: '1.5px solid #b0417a', width: '100%', fontWeight: 700, fontSize: 16, borderRadius: 8, padding: '10px 0' }}>Vaciar carrito</button>
            )}
          </aside>
          <div className="summary-card">
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatPrice(totalPrice)}</span>
            </div>
            <div className="summary-row">
              <span>IVA (19%)</span>
              <span>{formatPrice(iva)}</span>
            </div>
            <div className="summary-row">
              <span>Envío</span>
              <span>{formatPrice(shipping)}</span>
            </div>
            {shipping > 0 && (
              <div className="shipping-note">
                <small>💡 Envío gratis en compras sobre {formatPrice(50000)}</small>
              </div>
            )}
            <div className="summary-divider"></div>
            <div className="summary-total">
              <span>Total</span>
              <span>{formatPrice(finalTotal)}</span>
            </div>
            <div className="checkout-actions">
              <Link to="/catalogo" className="btn-continue-shopping">Seguir Comprando</Link>
              <button className="btn-cancel-checkout" onClick={() => navigate('/tienda')} style={{background:'#e8e2d8',color:'#b0417a',border:'1.5px solid #b0417a',marginRight:8}}>Cancelar Compra</button>
              <button className="btn-checkout" onClick={handleProcederPago} disabled={loading}>{loading ? 'Procesando...' : 'Finalizar Compra'}</button>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
};

export default Carrito;