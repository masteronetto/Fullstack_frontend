import React from 'react';

export default function CarritoSimple() {
    return (
        <div style={{ padding: '20px' }}>
            <h1>Carrito de Compras Simple</h1>
            <p>Si ves esto, la ruta del carrito funciona</p>
            
            <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '20px', borderRadius: '8px' }}>
                <h2>Tu Carrito</h2>
                <div style={{ marginTop: '15px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px', borderBottom: '1px solid #eee' }}>
                        <span>Polera Oversize Beige</span>
                        <span>$29.990</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px', borderBottom: '1px solid #eee' }}>
                        <span>Poleron Clásico Negro</span>
                        <span>$49.990</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px', fontWeight: 'bold', marginTop: '10px' }}>
                        <span>Total:</span>
                        <span>$79.980</span>
                    </div>
                </div>
                
                <button style={{ 
                    background: '#b0417a', 
                    color: 'white', 
                    padding: '12px 24px', 
                    border: 'none', 
                    borderRadius: '6px',
                    marginTop: '20px',
                    cursor: 'pointer'
                }}>
                    Proceder al Pago
                </button>
            </div>
            
            <div style={{ marginTop: '30px' }}>
                <a href="/" style={{ color: '#b0417a', textDecoration: 'underline' }}>Volver al Home</a>
                <span> | </span>
                <a href="/catalogo" style={{ color: '#b0417a', textDecoration: 'underline' }}>Seguir Comprando</a>
            </div>
        </div>
    );
}