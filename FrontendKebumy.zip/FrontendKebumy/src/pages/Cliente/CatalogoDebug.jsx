import React from 'react';

const CatalogoDebug = () => {
  console.log('🔍 CatalogoDebug component rendering');
  
  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h1>🛍️ Catálogo Debug</h1>
      <p>Si ves esto, la ruta funciona correctamente.</p>
      <p>Hora actual: {new Date().toLocaleTimeString()}</p>
    </div>
  );
};

export default CatalogoDebug;
