import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import useClientAuth from '../../../hooks/cliente/useClientAuth';
import useAuth from '../../../hooks/useAuth';
import apiService from '../../../services/apiService';
import './Checkout.css';

const Checkout = () => {
  const { pedidoId } = useParams();
  const navigate = useNavigate();
  const clientAuth = useClientAuth();
  const generalAuth = useAuth();
  const user = clientAuth.user || generalAuth.user;

  const [pedido, setPedido] = useState(null);
  const [loading, setLoading] = useState(true);
  const [procesando, setProcesando] = useState(false);
  const [metodoPago, setMetodoPago] = useState('tarjeta');
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!pedidoId) {
      navigate('/carrito');
      return;
    }
    cargarPedido();
  }, [pedidoId]);

  const cargarPedido = async () => {
    try {
      setLoading(true);
      const response = await apiService.getPedidoPorId(pedidoId);
      setPedido(response.pedido || response);
    } catch (error) {
      console.error('Error cargando pedido:', error);
      setError('No se pudo cargar el pedido');
    } finally {
      setLoading(false);
    }
  };

  const handleProcesarPago = async () => {
    if (!metodoPago) {
      alert('Selecciona un método de pago');
      return;
    }

    setProcesando(true);
    try {
      console.log(`💳 Procesando pago con método: ${metodoPago}`);
      const response = await apiService.procesarPago(pedidoId, metodoPago);
      
      if (response.success) {
        console.log('✅ Pago procesado exitosamente');
        navigate(`/pedido-exitoso/${pedidoId}`);
      } else {
        throw new Error('No se pudo procesar el pago');
      }
    } catch (error) {
      console.error('Error procesando pago:', error);
      alert('Error al procesar el pago: ' + error.message);
    } finally {
      setProcesando(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(price);
  };

  if (loading) {
    return (
      <div className="checkout-page">
        <Navbar />
        <div className="checkout-container">
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Cargando información del pedido...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !pedido) {
    return (
      <div className="checkout-page">
        <Navbar />
        <div className="checkout-container">
          <div className="error-state">
            <h2>❌ Error</h2>
            <p>{error || 'No se encontró el pedido'}</p>
            <button onClick={() => navigate('/catalogo')} className="btn-primary">
              Volver al catálogo
            </button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Unificar lógica de envío con Carrito
  const shipping = 5000;

  return (
    <div className="checkout-page">
      <Navbar />
      
      <div className="checkout-container">
        <div className="checkout-header">
          <h1>💳 Procesar Pago</h1>
          <p>Pedido #{pedido.numeroPedido}</p>
        </div>

        <div className="checkout-content">
          {/* Resumen del pedido */}
          <div className="pedido-resumen-card">
            <h2>📋 Resumen del Pedido</h2>
            
            <div className="resumen-items">
              {(pedido.items || []).map((item, index) => (
                <div key={index} className="item-row">
                  <span className="item-nombre">
                    {item.nombreProducto || item.producto?.nombre} x{item.cantidad}
                  </span>
                  <span className="item-precio">{formatPrice(item.subtotal)}</span>
                </div>
              ))}
            </div>

            <div className="resumen-totales">
              <div className="total-row">
                <span>Subtotal:</span>
                <span>{formatPrice(pedido.subtotal)}</span>
              </div>
              <div className="total-row">
                <span>IVA (19%):</span>
                <span>{formatPrice(pedido.iva !== undefined ? pedido.iva : Math.round((pedido.subtotal || 0) * 0.19))}</span>
              </div>

              {/* Cálculo robusto de IVA para el total */}
              {(() => {
                // Si el backend no envía IVA, lo calculamos aquí para el total
                if (pedido.iva === undefined) {
                  pedido.iva = Math.round((pedido.subtotal || 0) * 0.19);
                }
                return null;
              })()}
              <div className="total-row">
                <span>Envío:</span>
                <span>{formatPrice(5000)}</span>
              </div>
              <div className="total-row total-final">
                <span>Total:</span>
                <span>{formatPrice((pedido.subtotal || 0) + (pedido.iva !== undefined ? pedido.iva : Math.round((pedido.subtotal || 0) * 0.19)) + 5000)}</span>
              </div>
            </div>

            <div className="direccion-envio">
              <h3>📦 Dirección de Envío</h3>
              <p>{pedido.direccionEnvio}</p>
              <p>📞 {pedido.telefonoContacto}</p>
            </div>
          </div>

          {/* Métodos de pago */}
          <div className="metodos-pago-card">
            <h2>💳 Método de Pago</h2>
            
            <div className="metodos-pago-opciones">
              <label className={`metodo-opcion ${metodoPago === 'tarjeta' ? 'selected' : ''}`}>
                <input
                  type="radio"
                  name="metodoPago"
                  value="tarjeta"
                  checked={metodoPago === 'tarjeta'}
                  onChange={(e) => setMetodoPago(e.target.value)}
                />
                <div className="metodo-info">
                  <div className="metodo-icon">💳</div>
                  <div className="metodo-texto">
                    <strong>Tarjeta de Crédito/Débito</strong>
                    <small>Visa, Mastercard, American Express</small>
                  </div>
                </div>
              </label>

              <label className={`metodo-opcion ${metodoPago === 'paypal' ? 'selected' : ''}`}>
                <input
                  type="radio"
                  name="metodoPago"
                  value="paypal"
                  checked={metodoPago === 'paypal'}
                  onChange={(e) => setMetodoPago(e.target.value)}
                />
                <div className="metodo-info">
                  <div className="metodo-icon">🅿️</div>
                  <div className="metodo-texto">
                    <strong>PayPal</strong>
                    <small>Paga de forma segura con tu cuenta PayPal</small>
                  </div>
                </div>
              </label>

              <label className={`metodo-opcion ${metodoPago === 'webpay' ? 'selected' : ''}`}>
                <input
                  type="radio"
                  name="metodoPago"
                  value="webpay"
                  checked={metodoPago === 'webpay'}
                  onChange={(e) => setMetodoPago(e.target.value)}
                />
                <div className="metodo-info">
                  <div className="metodo-icon">🇨🇱</div>
                  <div className="metodo-texto">
                    <strong>Webpay Plus</strong>
                    <small>Transbank - Pago seguro chileno</small>
                  </div>
                </div>
              </label>
            </div>


            <button
              onClick={handleProcesarPago}
              disabled={procesando}
              className="btn-pagar"
            >
              {procesando ? (
                <>
                  <span className="spinner-small"></span>
                  Procesando pago...
                </>
              ) : (
                <>
                  💳 Pagar {formatPrice(pedido.total)}
                </>
              )}
            </button>
            <button
              className="btn-cancel-checkout"
              style={{
                background: '#b0417a',
                color: '#fff',
                border: 'none',
                fontWeight: 600,
                fontSize: 14,
                borderRadius: 7,
                padding: '7px 0',
                marginTop: 12,
                width: '100%',
                boxShadow: '0 2px 8px 0 rgba(176,65,122,0.10)',
                transition: 'background 0.2s',
                letterSpacing: 0.5
              }}
              onClick={() => navigate('/carrito')}
            >
              Cancelar compra
            </button>


            <div className="pago-seguro">
              <p>🔒 Pago 100% seguro y protegido</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Checkout;
