import React from 'react';

export default function CatalogoSimple() {
    return (
        <div style={{ padding: '20px' }}>
            <h1>Catálogo Simple</h1>
            <p>Si ves esto, la ruta del catálogo funciona</p>
            <div style={{ marginTop: '20px' }}>
                <h2>Productos de ejemplo:</h2>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginTop: '20px' }}>
                    <div style={{ border: '1px solid #ccc', padding: '10px', borderRadius: '8px' }}>
                        <h3>Polera Oversize</h3>
                        <p>Precio: $29.990</p>
                        <button style={{ background: '#b0417a', color: 'white', padding: '8px 16px', border: 'none', borderRadius: '4px' }}>
                            Agregar al Carrito
                        </button>
                    </div>
                    <div style={{ border: '1px solid #ccc', padding: '10px', borderRadius: '8px' }}>
                        <h3>Poleron Clásico</h3>
                        <p>Precio: $49.990</p>
                        <button style={{ background: '#b0417a', color: 'white', padding: '8px 16px', border: 'none', borderRadius: '4px' }}>
                            Agregar al Carrito
                        </button>
                    </div>
                </div>
            </div>
            <div style={{ marginTop: '30px' }}>
                <a href="/" style={{ color: '#b0417a', textDecoration: 'underline' }}>Volver al Home</a>
                <span> | </span>
                <a href="/carrito" style={{ color: '#b0417a', textDecoration: 'underline' }}>Ver Carrito</a>
            </div>
        </div>
    );
}