import React, { useState, useEffect } from 'react';
import { Navbar } from '../../../components/Navbar/Navbar';
import { Footer } from '../../../components/Footer/Footer';
import ProductCard from '../../../components/Cliente/ProductCard/ProductCard';
import useCart from '../../../hooks/cliente/useCart';
import apiService from '../../../services/apiService';
import './Catalogo.css';

const Catalogo = () => {
  const [productos, setProductos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filtros, setFiltros] = useState({
    categoria: 'TODAS',
    busqueda: '',
    ordenar: 'nombre'
  });
  const [categorias, setCategorias] = useState([]);

  useEffect(() => {
    cargarProductosYCategorias();
  }, []);

  const cargarProductosYCategorias = async () => {
    setLoading(true);
    setError(null);
    try {
      // Usar el nuevo método del catálogo
      const data = await apiService.getProductosCatalogo();
      
      // Normalizar datos del backend y eliminar duplicados
      let productosNormalizados = [];
      if (Array.isArray(data)) {
        productosNormalizados = data;
      } else if (data.productos && Array.isArray(data.productos)) {
        productosNormalizados = data.productos;
      } else if (data.data && Array.isArray(data.data)) {
        productosNormalizados = data.data;
      }
      
      // Eliminar duplicados por ID
      const idsVistos = new Set();
      const productosUnicos = productosNormalizados.filter(producto => {
        if (idsVistos.has(producto.id)) {
          console.log(`⚠️ Producto duplicado encontrado - ID: ${producto.id}, Nombre: ${producto.nombre}`);
          return false;
        }
        idsVistos.add(producto.id);
        return true;
      });
      
      console.log(`📦 Total productos recibidos del backend: ${productosNormalizados.length}`);
      console.log(`✅ Productos únicos después de deduplicación: ${productosUnicos.length}`);
      console.log('🔍 Lista de productos únicos:', productosUnicos);
      
      setProductos(productosUnicos);
      
      // Cargar categorías
      const categoriasData = await apiService.getCategorias();
      // Normalizar nombres de categorías (eliminar guiones y filtrar 'todas')
      const categoriasNormalizadas = categoriasData
        .map(cat => cat.replace(/-/g, ' ').trim())
        .filter(cat => cat.toLowerCase() !== 'todas');
      setCategorias(['TODAS', ...categoriasNormalizadas]);
      
      console.log('📦 Productos cargados:', data.length);
      console.log('📂 Categorías cargadas:', categoriasData);
      
    } catch (error) {
      console.error('❌ Error al cargar productos del backend:', error);
      setError('No se pudieron cargar los productos. Verifica tu conexión e inténtalo más tarde.');
      setProductos([]);
      setCategorias(['TODAS']);
    } finally {
      setLoading(false);
    }
  };

  const productosFiltrados = productos.filter(producto => {
    const nombreCategoria = (producto.categoria_nombre || producto.categoria || '').replace(/-/g, ' ').trim();
    const categoriaFiltro = filtros.categoria.replace(/-/g, ' ').trim();
    const coincideCategoria = !categoriaFiltro || 
      categoriaFiltro.toLowerCase() === 'todas' ||
      nombreCategoria.toLowerCase() === categoriaFiltro.toLowerCase();
    
    const coincideBusqueda = !filtros.busqueda || 
      producto.nombre.toLowerCase().includes(filtros.busqueda.toLowerCase()) ||
      producto.descripcion?.toLowerCase().includes(filtros.busqueda.toLowerCase());
    
    return coincideCategoria && coincideBusqueda;
  });

  const productosOrdenados = productosFiltrados.sort((a, b) => {
    switch (filtros.ordenar) {
      case 'precio-asc':
        return a.precio - b.precio;
      case 'precio-desc':
        return b.precio - a.precio;
      case 'nombre':
        return a.nombre.localeCompare(b.nombre);
      case 'categoria':
        const catA = a.categoria_nombre || a.categoria || '';
        const catB = b.categoria_nombre || b.categoria || '';
        return catA.localeCompare(catB);
      default:
        return 0;
    }
  });

  const handleFiltroChange = (campo, valor) => {
    setFiltros(prev => ({ ...prev, [campo]: valor }));
  };

  const limpiarFiltros = () => {
    setFiltros({
      categoria: 'TODAS',
      busqueda: '',
      ordenar: 'nombre'
    });
  };

  const handleViewDetails = (producto) => {
    // Aquí podrías abrir un modal o navegar a una página de detalles
    console.log('Ver detalles del producto:', producto);
    // Implementar modal de detalles o navegación
  };

  if (loading) {
    return (
      <div className="catalogo-page">
        <Navbar />
        <div className="loading-container">
          <div className="loading-spinner">
            <div className="spinner"></div>
            <p>Cargando productos...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="catalogo-page">
        <Navbar />
        <div className="error-container">
          <div className="error-message">
            <h2>😔 Oops! Algo salió mal</h2>
            <p>{error}</p>
            <button onClick={cargarProductosYCategorias} className="btn-retry">
              Intentar de nuevo
            </button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="catalogo-page">
      <Navbar />
      
      <div className="catalogo-container">
        {/* Header del catálogo */}
        <div className="catalogo-header">
          <h1>Nuestros Productos</h1>
          <p>Descubre nuestra colección de diseños únicos y productos personalizados</p>
        </div>

        {/* Filtros y búsqueda */}
        <div className="filtros-container">
          <div className="filtros-row">
            <div className="busqueda-container">
              <input
                type="text"
                placeholder="Buscar productos..."
                value={filtros.busqueda}
                onChange={(e) => handleFiltroChange('busqueda', e.target.value)}
                className="search-input"
              />
            </div>

            <div className="filtros-selects">
              <select
                value={filtros.categoria}
                onChange={(e) => handleFiltroChange('categoria', e.target.value)}
                className="filter-select"
              >
                <option value="">Todas las categorías</option>
                {categorias.map(categoria => (
                  <option key={categoria} value={categoria}>
                    {categoria}
                  </option>
                ))}
              </select>

              <select
                value={filtros.ordenar}
                onChange={(e) => handleFiltroChange('ordenar', e.target.value)}
                className="filter-select"
              >
                <option value="nombre">Ordenar por nombre</option>
                <option value="precio-asc">Precio: menor a mayor</option>
                <option value="precio-desc">Precio: mayor a menor</option>
                <option value="categoria">Por categoría</option>
              </select>

              <button onClick={limpiarFiltros} className="btn-clear-filters">
                Limpiar filtros
              </button>
            </div>
          </div>

          <div className="resultados-info">
            <span>
              {productosOrdenados.length} productos encontrados
              {filtros.categoria && ` en "${filtros.categoria}"`}
              {filtros.busqueda && ` para "${filtros.busqueda}"`}
            </span>
          </div>
        </div>

        {/* Grid de productos */}
        {productosOrdenados.length === 0 ? (
          <div className="no-products">
            <div className="no-products-content">
              <h3>😕 No se encontraron productos</h3>
              <p>
                {filtros.busqueda || filtros.categoria 
                  ? 'Intenta modificar los filtros de búsqueda'
                  : 'No hay productos disponibles en este momento'
                }
              </p>
              {(filtros.busqueda || filtros.categoria) && (
                <button onClick={limpiarFiltros} className="btn-clear-filters">
                  Ver todos los productos
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="productos-grid">
            {productosOrdenados.map(producto => (
              <ProductCard
                key={producto.id}
                producto={producto}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        )}

        {/* Categorías destacadas */}
        {(!filtros.categoria || filtros.categoria === 'TODAS') && !filtros.busqueda && (
          <div className="categorias-destacadas">
            <h2>Explora por categoría</h2>
            <div className="categorias-grid">
              {categorias.filter(cat => cat !== 'TODAS').map(categoria => (
                <button
                  key={categoria}
                  onClick={() => handleFiltroChange('categoria', categoria)}
                  className="categoria-card"
                >
                  <span>{categoria}</span>
                  <small>
                    {productos.filter(p => {
                      const catNombre = (p.categoria_nombre || p.categoria || '').replace(/-/g, ' ').trim();
                      return catNombre.toLowerCase() === categoria.toLowerCase();
                    }).length} productos
                  </small>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default Catalogo;