import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import authService from '../../services/authService';
import logoKebumy from '../../assets/logoKebumy.png';
import { BackendToggle } from '../../components/BackendToggle/BackendToggle';

export default function Login() {
    // 1. Estados para el formulario, carga y errores
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);
    
    // 2. Hook para redirección y autenticación
    const navigate = useNavigate();
    const location = useLocation();
    const { login, isAuthenticated, user } = useAuth();
    
    // 3. Redirigir si ya está autenticado
    useEffect(() => {
        if (isAuthenticated && user) {
            // Redirigir según el rol del usuario
            const defaultPath = user.rol === 'admin' || user.rol === 'super-admin' 
                ? '/admin-usuarios' 
                : '/catalogo';
            
            const from = location.state?.from?.pathname || defaultPath;
            navigate(from, { replace: true });
        }
    }, [isAuthenticated, user, navigate, location]);

    // 4. Lógica principal de autenticación
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        
        console.log('🔐 Iniciando proceso de login...');
        
        const credenciales = { 
            email, 
            password
        };

        try {
            console.log('📤 Enviando credenciales al backend...');
            
            // Usar el authService para login con manejo JWT automático
            const response = await authService.login(credenciales);
            
            console.log('✅ Login exitoso, respuesta del backend:', response);
            console.log('👤 Usuario:', response.usuario);
            console.log('🎭 Rol detectado:', response.usuario?.rol);
            
            // Usar el hook de autenticación con los datos del usuario
            const loginSuccess = login(response);
            
            if (loginSuccess) {
                console.log('🎯 Autenticación procesada exitosamente');
                // El redirect se hará automáticamente por el useEffect
            } else {
                throw new Error("Error al procesar la autenticación.");
            }

        } catch (err) {
            console.error('❌ Login Fallido:', err);
            setError(err.message || 'Credenciales incorrectas. Verifique su email y contraseña.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-container">
            <div className="login-box">
                {/* Logo de Kebumy */}
                <div style={{ textAlign: 'center', marginBottom: '30px' }}>
                    <img 
                        src={logoKebumy} 
                        alt="Kebumy Logo" 
                        style={{ width: '200px', marginBottom: '20px' }}
                    />
                    <h3 style={{ margin: '0', color: '#555' }}>Bienvenido a Kebumy</h3>
                    <p style={{ margin: '10px 0 0 0', color: '#888', fontSize: '14px' }}>
                        Inicia sesión para continuar
                    </p>
                </div>
                
                {/* Muestra el error si existe */}
                {error && (
                    <div style={{ 
                        backgroundColor: '#f8d7da', 
                        color: '#721c24', 
                        padding: '10px', 
                        borderRadius: '5px', 
                        marginBottom: '20px',
                        border: '1px solid #f5c6cb'
                    }}>
                        {error}
                    </div>
                )}
                
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="email">Email</label>
                        <input 
                            type="email" 
                            id="email" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)} 
                            required 
                            disabled={loading}
                            placeholder="admin@kebumy.com"
                        />
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="password">Contraseña</label>
                        <input 
                            type="password" 
                            id="password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                            disabled={loading}
                            placeholder="Ingrese su contraseña"
                        />
                        <a href="#" className="forgot-password">¿Olvidaste tu contraseña?</a>
                    </div>
                    
                    <button type="submit" className="submit-button" disabled={loading}>
                        {loading ? '🔐 Verificando credenciales...' : '🚀 Iniciar Sesión'}
                    </button>
                    
                    <div style={{ 
                        textAlign: 'center', 
                        marginTop: '20px', 
                        fontSize: '14px', 
                        color: '#666' 
                    }}>
                        ¿No tienes cuenta?{' '}
                        <Link 
                            to="/registro" 
                            style={{ 
                                color: '#667eea', 
                                textDecoration: 'none', 
                                fontWeight: '600' 
                            }}
                        >
                            Regístrate aquí
                        </Link>
                    </div>
                    
                    {/* Información de prueba */}
                    <div style={{ 
                        marginTop: '20px', 
                        padding: '10px', 
                        backgroundColor: '#d1ecf1', 
                        borderRadius: '5px',
                        fontSize: '12px',
                        color: '#0c5460'
                    }}>
                        <strong>💡 Usuarios de prueba:</strong><br />
                        <strong>Admin:</strong> admin@kebumy.com / admin123<br />
                        <strong>Cliente:</strong> cliente@kebumy.com / cliente123
                    </div>
                </form>
            </div>
            
            {/* Herramienta de diagnóstico y cambio de backend */}
            <BackendToggle />
        </div>
    );
}