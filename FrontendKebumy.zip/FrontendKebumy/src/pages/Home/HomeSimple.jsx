import React from 'react';

export default function HomeSimple() {
    return (
        <div>
            <h1>Test - Kebumy Home</h1>
            <p>Si ves esto, la aplicación básica funciona</p>
            <a href="/catalogo">Ir a Catálogo</a>
        </div>
    );
}