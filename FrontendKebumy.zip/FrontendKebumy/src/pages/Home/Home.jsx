import { Navbar } from '../../components/Navbar/Navbar';
import { Footer } from '../../components/Footer/Footer';
import useAuth from '../../hooks/useAuth';

export default function Home() {
    const { isAuthenticated, user, isAdmin } = useAuth();

    return (
        <div className="home-page">
            <Navbar />
            <main style={{ 
                minHeight: '80vh', 
                display: 'flex', 
                flexDirection: 'column', 
                justifyContent: 'center', 
                alignItems: 'center',
                backgroundColor: '#f7f3ed',
                padding: '40px 20px'
            }}>
                <div style={{
                    textAlign: 'center',
                    maxWidth: '800px',
                    backgroundColor: '#e8e2d8',
                    padding: '40px',
                    borderRadius: '12px',
                    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)'
                }}>
                    <h1 style={{ 
                        color: '#b0417a', 
                        fontFamily: "'Luckiest Guy', cursive",
                        fontSize: '3em',
                        marginBottom: '20px'
                    }}>
                        Bienvenido a Kebumy
                    </h1>
                    <p style={{ 
                        color: '#555', 
                        fontSize: '1.2em',
                        lineHeight: '1.6',
                        marginBottom: '30px'
                    }}>
                        Diseños únicos que reflejan lo especial que quieres transmitir. 
                        Explora nuestros productos personalizados y haz tu pedido especial.
                    </p>
                    <div style={{ 
                        display: 'flex', 
                        gap: '20px', 
                        justifyContent: 'center',
                        flexWrap: 'wrap'
                    }}>
                        <a 
                            href="/catalogo"
                            style={{
                                backgroundColor: '#b0417a',
                                color: 'white',
                                padding: '15px 40px',
                                borderRadius: '25px',
                                textDecoration: 'none',
                                fontSize: '1.2em',
                                fontWeight: 'bold',
                                transition: 'all 0.3s ease',
                                boxShadow: '0 4px 15px rgba(176, 65, 122, 0.3)'
                            }}
                        >
                            🛍️ Explorar Tienda
                        </a>
                        <a 
                            href="/contacto"
                            style={{
                                backgroundColor: '#925c93',
                                color: 'white',
                                padding: '12px 30px',
                                borderRadius: '20px',
                                textDecoration: 'none',
                                fontSize: '1.1em',
                                transition: 'background-color 0.2s'
                            }}
                        >
                            Contáctanos
                        </a>
                        
                        {/* Botón dinámico según autenticación */}
                        {isAuthenticated ? (
                            <a 
                                href={isAdmin() ? "/inventario" : "/mi-cuenta"}
                                style={{
                                    backgroundColor: '#6c757d',
                                    color: 'white',
                                    padding: '12px 30px',
                                    borderRadius: '20px',
                                    textDecoration: 'none',
                                    fontSize: '1.1em',
                                    transition: 'background-color 0.2s',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                👤 {isAdmin() ? 'Panel Admin' : 'Mi Cuenta'}
                            </a>
                        ) : (
                            <a 
                                href="/login"
                                style={{
                                    backgroundColor: '#6c757d',
                                    color: 'white',
                                    padding: '12px 30px',
                                    borderRadius: '20px',
                                    textDecoration: 'none',
                                    fontSize: '1.1em',
                                    transition: 'background-color 0.2s',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                🔑 Iniciar Sesión
                            </a>
                        )}
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}