import { useState, useEffect } from 'react';

const useAuth = () => {
  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem('kebumy_user');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const [token, setToken] = useState(() => {
    return localStorage.getItem('kebumy_token');
  });

  // Verificar si el usuario está autenticado y tiene un token válido
  const isAuthenticated = !!user && !!token && !!user.email;

  useEffect(() => {
    if (user) {
      localStorage.setItem('kebumy_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('kebumy_user');
    }
  }, [user]);

  useEffect(() => {
    if (token) {
      localStorage.setItem('kebumy_token', token);
    } else {
      localStorage.removeItem('kebumy_token');
    }
  }, [token]);

  const login = (responseData) => {
    console.log('🔍 useAuth - Procesando login con respuesta del backend:', responseData);
    
    // Validar estructura de respuesta del backend:
    // { success: true, message: "Login exitoso", token: "...", usuario: {...} }
    if (responseData && responseData.success && responseData.token && responseData.usuario) {
      const { token: jwtToken, usuario } = responseData;
      
      console.log('✅ useAuth - Token JWT recibido:', jwtToken.substring(0, 20) + '...');
      console.log('👤 useAuth - Datos de usuario:', usuario);
      console.log('🎭 useAuth - Rol del usuario:', usuario.rol);
      
      // Guardar token
      setToken(jwtToken);
      localStorage.setItem('kebumy_token', jwtToken);
      
      // Guardar usuario con toda la información del backend
      const userData = {
        id: usuario.id || usuario.id_usuario,
        email: usuario.email,
        nombre: usuario.nombre,
        rol: usuario.rol,
        tipo_usuario: usuario.tipo_usuario
      };
      
      setUser(userData);
      localStorage.setItem('kebumy_user', JSON.stringify(userData));
      
      console.log('✅ useAuth - Autenticación completada exitosamente');
      console.log('💾 useAuth - Usuario guardado en estado y localStorage');
      
      return true;
    }
    
    console.error('❌ useAuth - Estructura de respuesta inválida:', responseData);
    return false;
  };

  const logout = () => {
    console.log('🚪 useAuth - Cerrando sesión...');
    
    // Limpiar estado
    setUser(null);
    setToken(null);
    
    // Limpiar localStorage
    localStorage.removeItem('kebumy_user');
    localStorage.removeItem('kebumy_token');
    
    console.log('✅ useAuth - Sesión cerrada correctamente');
  };

  // Verificar si el token está expirado (decodificar JWT)
  const isTokenValid = () => {
    if (!token) return false;
    
    try {
      // Decodificar el payload del JWT (segunda parte)
      const payload = JSON.parse(atob(token.split('.')[1]));
      const currentTime = Math.floor(Date.now() / 1000);
      
      // Verificar si el token ha expirado
      if (payload.exp && payload.exp < currentTime) {
        console.warn('⚠️ Token JWT expirado');
        logout();
        return false;
      }
      
      return true;
    } catch (error) {
      console.error('❌ Error al validar token:', error);
      return false;
    }
  };

  // Función para verificar permisos basados en rol
  const hasRole = (requiredRole) => {
    if (!user) return false;
    
    // Verificar si el usuario tiene el rol requerido
    if (Array.isArray(requiredRole)) {
      return requiredRole.includes(user.rol);
    }
    
    return user.rol === requiredRole;
  };

  // Verificar si es administrador
  const isAdmin = () => {
    return hasRole(['admin', 'super-admin']);
  };

  // Verificar si es cliente
  const isCliente = () => {
    return hasRole('cliente');
  };

  return {
    user,
    token,
    isAuthenticated,
    login,
    logout,
    isTokenValid,
    hasRole,
    isAdmin,
    isCliente,
  };
};

export default useAuth;