import { useState, useEffect } from 'react';
import apiService from '../../services/apiService';

export const useCart = () => {
  const [cartItems, setCartItems] = useState(() => {
    const savedCart = localStorage.getItem('kebumy_cart');
    return savedCart ? JSON.parse(savedCart) : [];
  });

  // Guardar carrito en localStorage cuando cambie
  useEffect(() => {
    localStorage.setItem('kebumy_cart', JSON.stringify(cartItems));
    
    // Opcional: También guardar en el backend si el usuario está autenticado
    const saveCartToBackend = async () => {
      try {
        const cliente = JSON.parse(localStorage.getItem('kebumy_cliente') || 'null');
        if (cliente && cartItems.length > 0) {
          await apiService.guardarCarrito({
            clienteId: cliente.id,
            items: cartItems,
            timestamp: Date.now()
          });
        }
      } catch (error) {
        console.log('No se pudo guardar carrito en backend:', error);
        // No mostrar error al usuario, localStorage es suficiente
      }
    };

    // Debounce para no hacer muchas llamadas al backend
    const timeoutId = setTimeout(saveCartToBackend, 2000);
    return () => clearTimeout(timeoutId);
  }, [cartItems]);

  // Agregar producto al carrito
  const addToCart = (producto, cantidad = 1) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === producto.id);
      
      if (existingItem) {
        // Si ya existe, actualizar cantidad
        return prevItems.map(item =>
          item.id === producto.id
            ? { ...item, cantidad: item.cantidad + cantidad }
            : item
        );
      } else {
        // Si no existe, agregarlo
        return [...prevItems, { ...producto, cantidad }];
      }
    });
    
    console.log(`✅ Producto "${producto.nombre}" agregado al carrito`);
  };

  // Remover producto del carrito
  const removeFromCart = (productId) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
    console.log(`🗑️ Producto removido del carrito`);
  };

  // Actualizar cantidad de un producto
  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }

    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === productId
          ? { ...item, cantidad: newQuantity }
          : item
      )
    );
  };

  // Limpiar carrito
  const clearCart = () => {
    setCartItems([]);
    console.log('🧹 Carrito limpiado');
  };

  // Calcular total de items
  const getTotalItems = () => {
    return cartItems.reduce((total, item) => total + item.cantidad, 0);
  };

  // Calcular total de precio
  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + (item.precio * item.cantidad), 0);
  };

  // Verificar si un producto está en el carrito
  const isInCart = (productId) => {
    return cartItems.some(item => item.id === productId);
  };

  // Obtener cantidad de un producto específico
  const getItemQuantity = (productId) => {
    const item = cartItems.find(item => item.id === productId);
    return item ? item.cantidad : 0;
  };

  return {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getTotalItems,
    getTotalPrice,
    isInCart,
    getItemQuantity
  };
};

export default useCart;