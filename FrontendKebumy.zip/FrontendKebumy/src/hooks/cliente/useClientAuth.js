import { useState, useEffect } from 'react';

const useClientAuth = () => {
  const [cliente, setCliente] = useState(() => {
    const storedClient = localStorage.getItem('kebumy_cliente');
    return storedClient ? JSON.parse(storedClient) : null;
  });

  // Verificar si el cliente está autenticado
  const isClientAuthenticated = !!cliente && cliente.rol === 'cliente';

  useEffect(() => {
    if (cliente) {
      localStorage.setItem('kebumy_cliente', JSON.stringify(cliente));
    } else {
      localStorage.removeItem('kebumy_cliente');
    }
  }, [cliente]);

  const loginClient = (clientData) => {
    console.log('🔍 useClientAuth - Recibiendo datos para login cliente:', clientData);
    
    const email = clientData?.email;
    const rol = clientData?.rol;
    
    // Validar que sea un cliente válido
    if (clientData && email && (rol === 'cliente' || !rol)) {
      const normalizedClient = {
        ...clientData,
        rol: 'cliente'
      };
      
      console.log('✅ useClientAuth - Cliente autenticado:', normalizedClient);
      setCliente(normalizedClient);
      return true;
    }
    
    console.log('❌ useClientAuth - Datos inválidos para login cliente');
    return false;
  };

  const logoutClient = () => {
    setCliente(null);
    localStorage.removeItem('kebumy_cliente');
    localStorage.removeItem('kebumy_cart'); // Limpiar carrito al cerrar sesión
    console.log('👋 Cliente deslogueado');
  };

  const registerClient = async (clientData) => {
    try {
      // Aquí irá la lógica para registrar un nuevo cliente
      const newClient = {
        ...clientData,
        rol: 'cliente',
        estado: 'activo',
        fechaCreacion: new Date().toISOString()
      };

      console.log('📝 Registrando nuevo cliente:', newClient);
      return newClient;
    } catch (error) {
      console.error('❌ Error al registrar cliente:', error);
      throw error;
    }
  };

  const updateClientProfile = (updatedData) => {
    if (cliente) {
      const updatedClient = { ...cliente, ...updatedData };
      setCliente(updatedClient);
      console.log('✅ Perfil de cliente actualizado');
      return true;
    }
    return false;
  };

  return {
    cliente,
    user: cliente, // Alias para compatibilidad
    isClientAuthenticated,
    isAuthenticated: isClientAuthenticated, // Alias para compatibilidad
    loginClient,
    login: loginClient, // Alias para compatibilidad
    logoutClient,
    logout: logoutClient, // Alias para compatibilidad
    registerClient,
    updateClientProfile,
    updateUser: updateClientProfile // Alias para compatibilidad
  };
};

export default useClientAuth;
export { useClientAuth };