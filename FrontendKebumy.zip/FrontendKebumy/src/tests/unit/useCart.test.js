import { describe, it, expect, afterEach, vi } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useCart } from '../../hooks/cliente/useCart';

describe('useCart Hook', () => {
  afterEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  it('debe inicializar con un carrito vacío', () => {
    const { result } = renderHook(() => useCart());

    expect(result.current.cartItems).toEqual([]);
    expect(result.current.getTotalItems()).toBe(0);
    expect(result.current.getTotalPrice()).toBe(0);
  });

  it('debe agregar un producto al carrito', () => {
    const { result } = renderHook(() => useCart());
    
    const producto = {
      id: 1,
      nombre: 'Producto Test',
      precio: 1000,
      imagen: 'test.jpg'
    };

    act(() => {
      result.current.addToCart(producto);
    });

    expect(result.current.cartItems).toHaveLength(1);
    expect(result.current.cartItems[0]).toMatchObject({
      id: 1,
      nombre: 'Producto Test',
      precio: 1000,
      cantidad: 1
    });
    expect(result.current.getTotalItems()).toBe(1);
  });

  it('debe incrementar la cantidad si el producto ya existe en el carrito', () => {
    const { result } = renderHook(() => useCart());
    
    const producto = {
      id: 1,
      nombre: 'Producto Test',
      precio: 1000,
      imagen: 'test.jpg'
    };

    act(() => {
      result.current.addToCart(producto);
      result.current.addToCart(producto);
    });

    expect(result.current.cartItems).toHaveLength(1);
    expect(result.current.cartItems[0].cantidad).toBe(2);
    expect(result.current.getTotalItems()).toBe(2);
  });

  it('debe calcular correctamente el total del precio', () => {
    const { result } = renderHook(() => useCart());
    
    const producto1 = { id: 1, nombre: 'Producto 1', precio: 1000, imagen: 'test1.jpg' };
    const producto2 = { id: 2, nombre: 'Producto 2', precio: 2000, imagen: 'test2.jpg' };

    act(() => {
      result.current.addToCart(producto1);
      result.current.addToCart(producto1); // cantidad: 2
      result.current.addToCart(producto2); // cantidad: 1
    });

    // 1000 * 2 + 2000 * 1 = 4000
    expect(result.current.getTotalPrice()).toBe(4000);
  });

  it('debe eliminar un producto del carrito', () => {
    const { result } = renderHook(() => useCart());
    
    const producto = {
      id: 1,
      nombre: 'Producto Test',
      precio: 1000,
      imagen: 'test.jpg'
    };

    act(() => {
      result.current.addToCart(producto);
    });

    expect(result.current.cartItems).toHaveLength(1);

    act(() => {
      result.current.removeFromCart(1);
    });

    expect(result.current.cartItems).toHaveLength(0);
    expect(result.current.getTotalItems()).toBe(0);
  });

  it('debe actualizar la cantidad de un producto', () => {
    const { result } = renderHook(() => useCart());
    
    const producto = {
      id: 1,
      nombre: 'Producto Test',
      precio: 1000,
      imagen: 'test.jpg'
    };

    act(() => {
      result.current.addToCart(producto);
    });

    act(() => {
      result.current.updateQuantity(1, 5);
    });

    expect(result.current.cartItems[0].cantidad).toBe(5);
    expect(result.current.getTotalItems()).toBe(5);
    expect(result.current.getTotalPrice()).toBe(5000);
  });

  it('debe limpiar todo el carrito', () => {
    const { result } = renderHook(() => useCart());
    
    const producto1 = { id: 1, nombre: 'Producto 1', precio: 1000, imagen: 'test1.jpg' };
    const producto2 = { id: 2, nombre: 'Producto 2', precio: 2000, imagen: 'test2.jpg' };

    act(() => {
      result.current.addToCart(producto1);
      result.current.addToCart(producto2);
    });

    expect(result.current.cartItems).toHaveLength(2);

    act(() => {
      result.current.clearCart();
    });

    expect(result.current.cartItems).toHaveLength(0);
    expect(result.current.getTotalItems()).toBe(0);
    expect(result.current.getTotalPrice()).toBe(0);
  });

  it('debe persistir el carrito en localStorage', () => {
    const { result } = renderHook(() => useCart());
    
    const producto = {
      id: 1,
      nombre: 'Producto Test',
      precio: 1000,
      imagen: 'test.jpg'
    };

    act(() => {
      result.current.addToCart(producto);
    });

    expect(localStorage.setItem).toHaveBeenCalledWith(
      'kebumy_cart',
      expect.any(String)
    );
  });
});
