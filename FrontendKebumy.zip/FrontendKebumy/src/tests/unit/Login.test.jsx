import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BrowserRouter } from 'react-router-dom';
import Login from '../../pages/Login/Login';
import authService from '../../services/authService';

// Mock del authService
vi.mock('../../services/authService', () => ({
  default: {
    login: vi.fn()
  }
}));

// Mock de useNavigate
const mockNavigate = vi.fn();
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockNavigate
  };
});


describe('Login Component', () => {
  afterEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  it('debe renderizar el formulario de login correctamente', () => {
    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );

    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/contraseña/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /iniciar sesión/i })).toBeInTheDocument();
  });

  it('debe intentar hacer login cuando se envía el formulario', async () => {
    const user = userEvent.setup();
    
    authService.login.mockResolvedValueOnce({
      success: false,
      message: 'Credenciales inválidas'
    });

    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );

    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/contraseña/i);
    const submitButton = screen.getByRole('button', { name: /iniciar sesión/i });

    await user.type(emailInput, 'test@test.com');
    await user.type(passwordInput, 'password');
    await user.click(submitButton);

    await waitFor(() => {
      expect(authService.login).toHaveBeenCalledWith({
        email: 'test@test.com',
        password: 'password'
      });
    });
  });

  it('debe llamar al servicio de autenticación con credenciales válidas', async () => {
    const user = userEvent.setup();
    const mockResponse = {
      success: true,
      token: 'fake-token',
      usuario: {
        id: 1,
        email: 'test@test.com',
        nombre: 'Test User',
        rol: 'cliente'
      }
    };

    authService.login.mockResolvedValueOnce(mockResponse);

    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );

    const emailInput = screen.getByRole('textbox', { name: /email/i });
    const passwordInput = screen.getByLabelText(/contraseña/i);
    const submitButton = screen.getByRole('button', { name: /iniciar sesión/i });

    await user.type(emailInput, 'test@test.com');
    await user.type(passwordInput, 'password123');
    await user.click(submitButton);

    await waitFor(() => {
      expect(authService.login).toHaveBeenCalled();
    });
  });

  it('debe redirigir al catálogo cuando el login es exitoso (rol cliente)', async () => {
    const user = userEvent.setup();
    const mockResponse = {
      success: true,
      token: 'fake-token',
      usuario: {
        id: 1,
        email: 'cliente@test.com',
        nombre: 'Cliente Test',
        rol: 'cliente'
      }
    };

    authService.login.mockResolvedValueOnce(mockResponse);

    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );

    const emailInput = screen.getByPlaceholderText(/admin@kebumy\.com/i);
    const passwordInput = screen.getByPlaceholderText(/ingrese su contraseña/i);
    const submitButton = screen.getByRole('button', { name: /iniciar sesión/i });

    await user.type(emailInput, 'cliente@test.com');
    await user.type(passwordInput, 'password123');
    await user.click(submitButton);

    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalledWith('/catalogo', { replace: true });
    });
  });

  it('debe redirigir al inventario cuando el login es exitoso (rol admin)', async () => {
    const user = userEvent.setup();
    const mockResponse = {
      success: true,
      token: 'fake-token',
      usuario: {
        id: 2,
        email: 'admin@test.com',
        nombre: 'Admin Test',
        rol: 'admin'
      }
    };

    authService.login.mockResolvedValueOnce(mockResponse);

    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );

    const emailInput = screen.getByPlaceholderText(/admin@kebumy\.com/i);
    const passwordInput = screen.getByPlaceholderText(/ingrese su contraseña/i);
    const submitButton = screen.getByRole('button', { name: /iniciar sesión/i });

    await user.type(emailInput, 'admin@test.com');
    await user.type(passwordInput, 'admin123');
    await user.click(submitButton);

    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalled();
      // Admin redirecciona a /catalogo por defecto
    });
  });
});
