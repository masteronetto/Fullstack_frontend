import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { BrowserRouter } from 'react-router-dom';
import ProtectedRoute from '../../components/ProtectedRoute';

// Mock de useNavigate y Navigate para evitar bloqueos en tests
const mockNavigate = vi.fn();
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
    Navigate: function NavigateMock(props) { return <div data-testid="mock-navigate">Navigate to: {props.to}</div>; }
  };
});

// Mock del hook useAuth
vi.mock('../../hooks/useAuth', () => ({
  default: vi.fn()
}));

// Componente de prueba simple
const TestComponent = () => <div>Contenido Protegido</div>;

describe('ProtectedRoute', () => {
  let useAuth;

    beforeEach(async () => {
      vi.clearAllMocks();
      localStorage.clear();
      useAuth = (await import('../../hooks/useAuth')).default;
      mockNavigate.mockClear();
  });

  it('debe mostrar el contenido cuando el usuario está autenticado', () => {
    useAuth.mockReturnValue({
      user: { id: 1, email: 'admin@test.com', rol: 'admin' },
      isAuthenticated: true,
      isTokenValid: () => true
    });

    render(
      <BrowserRouter>
        <ProtectedRoute requiredRole={['admin']}>
          <TestComponent />
        </ProtectedRoute>
      </BrowserRouter>
    );

    expect(screen.getByText('Contenido Protegido')).toBeInTheDocument();
  });

  it('debe redirigir a /login cuando el usuario no está autenticado', () => {
    useAuth.mockReturnValue({
      user: null,
      isAuthenticated: false,
      isTokenValid: () => false
    });

    render(
      <BrowserRouter>
        <ProtectedRoute requiredRole={['admin']}>
          <TestComponent />
        </ProtectedRoute>
      </BrowserRouter>
    );

    // Verifica que el mock de Navigate se renderizó
    expect(screen.getByTestId('mock-navigate')).toBeInTheDocument();
  });

  it('debe bloquear el acceso cuando el rol no coincide', () => {
    useAuth.mockReturnValue({
      user: { id: 2, email: 'cliente@test.com', rol: 'cliente' },
      isAuthenticated: true,
      isTokenValid: () => true
    });

    render(
      <BrowserRouter>
        <ProtectedRoute requiredRole={['admin', 'super-admin']}>
          <TestComponent />
        </ProtectedRoute>
      </BrowserRouter>
    );

    // No debe mostrar el contenido protegido
    expect(screen.queryByText('Contenido Protegido')).not.toBeInTheDocument();
  });

  it('debe permitir acceso cuando el rol está en la lista de roles permitidos', () => {
    useAuth.mockReturnValue({
      user: { id: 1, email: 'admin@test.com', rol: 'admin' },
      isAuthenticated: true,
      isTokenValid: () => true
    });

    render(
      <BrowserRouter>
        <ProtectedRoute requiredRole={['admin', 'super-admin', 'moderador']}>
          <TestComponent />
        </ProtectedRoute>
      </BrowserRouter>
    );

    expect(screen.getByText('Contenido Protegido')).toBeInTheDocument();
  });

  it('debe manejar el estado correctamente cuando no hay usuario', () => {
    useAuth.mockReturnValue({
      user: null,
      isAuthenticated: false,
      isTokenValid: () => false
    });

    const { container } = render(
      <BrowserRouter>
        <ProtectedRoute requiredRole={['admin']}>
          <TestComponent />
        </ProtectedRoute>
      </BrowserRouter>
    );

    // Debería existir el container aunque no muestre contenido
    expect(container).toBeTruthy();
  });
});
