import { describe, it, expect, afterEach, vi } from 'vitest';

// Mock de fetch
global.fetch = vi.fn();

describe('ApiService', () => {
  afterEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    fetch.mockClear();
  });

  it('debe inicializar correctamente el servicio', async () => {
    const mockToken = 'fake-jwt-token';
    localStorage.setItem('kebumy_token', mockToken);

    const apiService = (await import('../../services/apiService')).default;
    
    expect(apiService).toBeDefined();
    expect(localStorage.getItem('kebumy_token')).toBe(mockToken);
  });

  it('debe manejar errores 404 correctamente', async () => {
    fetch.mockResolvedValueOnce({
      ok: false,
      status: 404,
      json: async () => ({ message: 'Recurso no encontrado' })
    });

    const apiService = (await import('../../services/apiService')).default;
    
    try {
      await apiService.getProducto(999);
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it('debe formatear datos de productos correctamente', () => {
    const producto = {
      id: 1,
      nombre: 'Producto Test',
      precio: 15000
    };

    expect(producto.precio).toBeGreaterThan(0);
    expect(producto.nombre).toBeDefined();
  });

  it('debe formatear correctamente los precios chilenos', () => {
    const precio = 25990;
    const formatted = new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(precio);

    expect(formatted).toContain('25.990');
  });
});
