import { describe, it, expect, afterEach, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { Navbar } from '../../components/Navbar/Navbar';

// Mock de useAuth
vi.mock('../../hooks/useAuth', () => ({
  default: vi.fn()
}));

// Mock de CartWidget
vi.mock('../../components/CartWidget/CartWidget', () => ({
  default: () => <div data-testid="cart-widget">Cart</div>
}));

import useAuth from '../../hooks/useAuth';

describe('Navbar Component', () => {
  afterEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });
  it('debe renderizar el navbar con logo y enlaces básicos', () => {
    useAuth.mockReturnValue({
      user: null,
      isAuthenticated: false
    });

    render(
      <BrowserRouter>
        <Navbar />
      </BrowserRouter>
    );

    expect(screen.getByText(/inicio/i)).toBeInTheDocument();
    expect(screen.getByText(/tienda/i)).toBeInTheDocument();
    expect(screen.getByText(/contacto/i)).toBeInTheDocument();
  });

  it('debe mostrar enlaces de admin cuando el usuario es administrador', () => {
    useAuth.mockReturnValue({
      user: { id: 1, email: 'admin@test.com', rol: 'admin' },
      isAuthenticated: true,
      isAdmin: () => true,
      isCliente: () => false
    });

    render(
      <BrowserRouter>
        <Navbar />
      </BrowserRouter>
    );

    expect(screen.getByText(/inventario/i)).toBeInTheDocument();
    expect(screen.getByText(/usuarios/i)).toBeInTheDocument();
    expect(screen.getByText(/gestión pedidos/i)).toBeInTheDocument();
  });

  it('debe mostrar enlaces de cliente cuando el usuario es cliente', () => {
    useAuth.mockReturnValue({
      user: { id: 2, nombre: 'Cliente', rol: 'cliente' },
      isAuthenticated: true,
      isAdmin: () => false,
      isCliente: () => true
    });

    render(
      <BrowserRouter>
        <Navbar />
      </BrowserRouter>
    );

    expect(screen.getByText(/mis pedidos/i)).toBeInTheDocument();
    expect(screen.getByText(/mi cuenta/i)).toBeInTheDocument();
    // Verificar que el carrito está presente por su emoji
    expect(screen.getByRole('button', { name: /🛒/i })).toBeInTheDocument();
  });

  it('debe mostrar el botón de cerrar sesión cuando está autenticado', () => {
    useAuth.mockReturnValue({
      user: { id: 1, nombre: 'Usuario', rol: 'cliente' },
      isAuthenticated: true,
      isAdmin: () => false,
      isCliente: () => true
    });

    render(
      <BrowserRouter>
        <Navbar />
      </BrowserRouter>
    );

    expect(screen.getByText(/cerrar sesión/i)).toBeInTheDocument();
  });

  it('debe mostrar el carrito para usuarios no autenticados', () => {
    useAuth.mockReturnValue({
      user: null,
      isAuthenticated: false,
      isAdmin: () => false
    });

    render(
      <BrowserRouter>
        <Navbar />
      </BrowserRouter>
    );

    // Verificar que existe el botón del carrito
    const cartButtons = screen.getAllByRole('button');
    expect(cartButtons.length).toBeGreaterThan(0);
  });
});
